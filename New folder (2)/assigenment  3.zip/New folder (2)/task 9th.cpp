#include< iostream>
using namespace std; 
float  arr[5][7];
void fun() {

	for (int i = 0; i < 3; i++) {
		 
		int sum = 0;
		for (int j = 0; j < 7; j++) {
			cout << "enter the arr "<< i<<j<< endl;
			cin >> arr[i][j];
			
		}
	}

	for (int i = 0; i < 3; i++) {
		float ave = 0;
		int sum = 0;
		for (int j = 0; j < 7; j++) {
			cout << "enter the arr " << i << j << endl;

			cin >> arr[i][j];
			sum += arr[i][j];
			ave = sum / 7;
			cout << " this the ave per shift" << ave << endl;
			cout << " this the ave per day" << arr[i][j] << endl;
			if (ave > 10) {
				cout << " this the average of  cirtical shift no :  " << i << endl;
			}
		}
	}
}


int main() {

	fun() ;

	return 0; 
}