#include< iostream>
using namespace std;
char location[5][10];
float temp[5][5];
void fun() {


	for (int i = 1; i < 6; i++) {
		cout << " enter the location of the" << endl;
		cin.ignore();
		cin.getline(location [i],10);

		for (int j = 1; j < 6; j++) {
			cout << " enter the temp of loc in different seasns  " << j << endl;
			cin >> temp[i][j];
		}
	}
	

	float ave = 0;
	int largest = INT_MIN ; 
	int sum = 0; 

	for (int i = 1; i < 6; i++) {
		cout << " see the location of the" << endl;
		cout<< location[i],15 ;
		for (int j = 1; j < 6; j++) {
			cout << " enter the temp of loc in different seasns  " << j << endl;
			cout<< temp[i][j];
			sum += temp[i][j];
			ave = sum / 5;
			cout << " this the average season :" <<ave << endl;
			if (temp[i][j] > largest ){
				largest = temp[i][j];
				cout << "this the  is the extrem temp of the season" << location[i], 15;
					cout<<"  <-   this will be the lrgest temp of the \n: " << largest;
			  }

		}
	}



}

int  main() {

	fun();
	return 0;
}