#include<iostream>
using namespace std;
char  arr[5][5];
void fun () {

	for (int i = 0; i < 5; i++) {

		for (int j = 0; j < 5; j++) {
			cout << " enter the arr arr [" << i << "][" << j << "]" << endl;
			cin >> arr[i][j];
		}
	}
	// now for the seeing the arr  
	int I, M, A = 0; 
	
	for (int i = 0; i < 5; i++) {
		int large_m = 0; 
		int l_mixed = INT_MIN;
		for (int j = 0; j < 5; j++) {
			cout << " enter the arr arr [" << i << "][" << j << "]" << endl;
			cout << arr[i][j];
			if (arr[i][j] == 'a') {
				A++;
			}else if (arr[i][j] == 'm'){
				
				M++;
			}
			else if (arr[i][j] == 'I')
			{
				I++;
			}

			
			if (arr[i][j] == 'm') {
				
				if ( M > l_mixed ){
					l_mixed = M;
					cout << " this the  largest missed in the each row " << l_mixed << endl;

			    }

			}



		}
		cout << endl;
	}





}
int  main() {


	return 0;
}