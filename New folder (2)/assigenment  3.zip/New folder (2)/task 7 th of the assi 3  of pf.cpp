#include <iostream>
using namespace std;
int rating[10][5];
char name [10][10];
void  fun() {

	
	cout << "see the inputed data " << endl;

	for (int i = 1; i < 6  ; i++) {
		cout << "name of the product " << endl;
		cin.ignore();
		cin.getline(name[i], 10);
			float ave = 0; 
			int  sum = 0; 
			int  samll = INT_MAX;

		for (int j = 1; j < 11; j++){
			int c1 = 0;
			cin >> rating[i][j];
			 sum += rating[i][j];
			 ave = sum / 5;
			 cout << " this will the average rating for each product " << ave << " this is the name of product : " << name[i], 10;
			 if (rating[i][j] == 5 ) {
				 c1++;
				 cout << "these no of peoples have given the 100 % rating 5 out of 5  "<<c1<<" to this product "<< name[i], 10;
			 }
			 if (ave < samll){
				 samll = ave;
				 cout << " this the smallest average " <<endl; 

			  }
			 
		}
		cout << endl;
	}





 }
int main() {


	fun(); 

	return 0; 
}