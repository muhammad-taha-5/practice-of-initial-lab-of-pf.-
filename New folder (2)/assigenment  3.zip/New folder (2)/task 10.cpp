#include<iostream>
using namespace std;
int  arr[4][6];
void fun () {

	for (int i = 0; i < 4; i++) {

		for (int j = 0; j < 6; j++ ) {
			cout << " enter the arr "<<i << j<<  endl;
			cin >> arr[i][j];
		}
	}
	int large = INT_MIN; 
	for (int i = 0; i < 4; i++) {
		int   v1 = 0;
		int sum = 0; 
		for (int j = 0; j < 6; j++) {
			cout<< "these are the votes per ppoling station  " << arr[i][j];
			v1++;
			cout << "these are the votes per cadidate " << v1 << endl;
			sum += arr[i][j];
			if (sum > large ) {
				large = sum;
				cout << " this the winer " << large << " polling  no : " << i << endl;
			}
			if (sum < 100 ) {
				cout << " this is the station in which  less than 100 votes are conducted " << i << endl;
			}

		}

	}



}

int main() {

	fun();


	return 0; 
}