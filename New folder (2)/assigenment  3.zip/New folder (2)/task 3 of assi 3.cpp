#include< iostream>
using namespace std;
char stutus [5][5];

void fun(){
	char arr1[4] = { "stb" };
	char  arr2[4] = { "cir" };
	char arr3[4]={"rec"};
	
	int c1 = 0;
	int c2 = 0;
		int c3 =0 ;
	for (int i = 1; i < 6; i++ ) {
		cout << " enter the situations of the" << endl;
		cin.getline(stutus[5],10);
		for (int j = 0; j < 7; j++){
			if (stutus[i][j] == arr1[j] ){
				
				c1++;
			}else if (stutus[i][j] == arr2[j]) {
				cout << " the day at which patient remaind cirtical " << j << endl;
				c2++;
			}else if (stutus[i][j] == arr3[j]) {
				c3++;
			}

		}
	}




}

int  main() {

	fun();
	return 0; 
}