////
//#include<iostream >
//using namespace std;
//char name[10][15];
//int arr[2][5];
//
//
//void fun(char name[10][15], int arr[2][5] ) {
//	
//	
//	for (int i = 0; i < 10; i++) {
//		cout << " enter the name ";
//		cin.ignore();
//		cin.getline(name[i], 15);
//		int s_no = 0;;
//		for (int j = 0; j < 5; j++) {
//
//			cout << " enter the marks of every subject " << s_no++;
//			cin >> arr[i][j];
//		}
//	}
//	
//	for (int i = 0; i < 10; i++){
//			int total = 0;
//			float ave = 0; 
//		cout << "name\n" << name[i],15;
//
//		for (int j = 0; j < 5; j++){
//			cout << "  marks of s:\n  "<< j<<" :"<<arr[i][j];
//			total += arr[i][j];
//			ave = total / 5;
//		}
//		cout << " these are the total :" << total << endl;
//		cout << " this the ave of the  student :" << ave << endl;
//		char name[15];
//		float ave_largest = INT_MIN;
//		 if (ave > ave_largest){
//			 ave_largest = ave;  
//			 name[i] = name[i],15;
//
//			 cout << " this one is the toper \n" << ave_largest << name[i] <<"   "<< name[i],15 ;
//			 cout << " he will recive the grade of A  " << endl;
//		 }
//		 else if( ave >40 ){
//			 cout << " he will recive the grade of B  " << endl;
//		 }
//		 else if (ave > 30) {
//			 cout << " he will recive the grade of C  " << endl;
//		 }
//		 else if (ave > 20) {
//			 cout << " he will recive the grade of D  " << endl;
//		 }
//
//
//
//	}
//}
//  // now 2nd usre difine fun 
// // for assignig the grades to student 
//void grade ( ) {
//
//	for (int i = 0; i < 10; i++) {
//		
//		for (int j = 0; j < 5; j++) {
//		
//
//
//		}
//
//
//	}
//
//
//
//
//
//
//}
//
//
//
//
//int main() 
//{
//
//	fun(name, arr);
//
//	return 0; 
//}