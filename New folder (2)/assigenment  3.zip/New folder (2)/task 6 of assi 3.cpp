#include<iostream>
using namespace std;
char  seats[6][4];
void fun( ){
	int index = 1;
	for (int i = 0; i < 6; i++ ){
		for (int j = 0; j < 4; j++) {
			cout << "enter the seats :"  <<i << j<<" enter the seat no: " << index++ << endl;
			cin >> seats[i][j];
		}
	}
	// now for the seeing seats 
	int large = INT_MIN;
		int   count_seats = 0;
	for (int i = 0; i < 6; i++) {
		int max_in_row = 0;
		for (int j = 0; j < 4; j++) {
			cout << seats[i][j] << " ";
			if ( seats[i][j] == 'e' ){
				count_seats++;
				cout << " these  the  total numbers of the seats are avalable" << count_seats << endl;

		    }
			if (seats[i][j] == 'e') {
				max_in_row++;
				cout << " these  the  total numbers of the seats are avalable in each row " << max_in_row << endl;

				if (max_in_row > large) {
					large = max_in_row;
					cout << " these ARE the MAX seats are avalable in each row " << large << endl;
					
				}
			}



		}
		cout<< endl;
	}

	// now for the booing the seat 
	char name[100];
	for (int i = 0; i < 6; i++) {
		for (int j = 0; j < 4; j++) {
			cout << " enter the wr to index location of seats " << endl;
			cin >> i >> j;
			
			if (seats[i][j] == 'e') {
				cout << " enter  your name for the for proper booking " << endl;
				cin.ignore();
				cin.getline(name, 100);
				seats[i][j] = 'b';

			}
		}
	}
	















}
int main(){
	fun() ;

	return 0;
}