#include<iostream>
using namespace std; 
char team_name[6][10]; 
int  arr_score [6][4];
void fun(){

	for (int i = 1; i < 7; i++) {
		cout << " enter the name of each team " << i << endl;
		cin.ignore(); 
		cin.getline( team_name[i],10);
		for (int j = 0; j < 11; j++) {
			cin >> arr_score[i][j];
		}
	}

// now for the seeing the data inputed 
	int large = INT_MIN;
	for (int i = 1; i < 7; i++){
		cout << " enter the name of each team " << i << endl;
		cin.ignore();
		cin.getline(team_name[i], 10);
		int totalscore = 0; 
		int fail_team = 10 ; 
		for (int j = 0; j < 4; j++){
			cout << " enter the scoreof the members of the each team " << j << endl;
			cin >> arr_score[i][j];
			totalscore += arr_score[i][j];
			cout << " this the name of the team " << team_name[i], 10;
			cout << " this the total score per team " << totalscore << endl;
			cout << endl;
			cout << endl;
			if (totalscore > large ){
				large = totalscore;
				cout << " this the name  name of the winner team  " << team_name[i],10 ;
				cout << " this the largest scorces form all teams " << totalscore <<endl;
				cout << endl;
				cout << endl;
			}
			if (totalscore < fail_team){
				fail_team = totalscore;
				cout << " ths the team that is losser " << team_name[i], 10;
				cout << "  this the score of the team " << totalscore << endl;
				cout << endl;
				cout << endl;

			}
		}
	}






}
int main(){

	fun();



	return 0; 
}