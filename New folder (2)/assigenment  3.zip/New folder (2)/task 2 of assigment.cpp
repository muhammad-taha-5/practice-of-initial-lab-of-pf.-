//#include<iostream>
//using namespace std;
//char dish[4][10];
//int days[7][7];
//
//void fun() {
//
//	for (int i = 1; i < 5; i++) {
//		cout << " enter the names of dishs " << i << endl;
//		cin.ignore();
//		cin.getline(dish[i], 10);
//
//		for (int j = 0; j < 7; j++) {
//			cin >> days[i][j];
//		}
//	}
//	//
//	int total_s_w = 0;
//	for (int i = 1; i < 5; i++) {
//
//		cout << " now for seeing the names of dishs \n" << dish[i], 10;
//
//		cout << " " << dish[i], 10;
//		int total_s_d = 0;
//		for (int j = 1; j < 8; j++) {
//			int large = INT_MIN;
//			cout << " " << days[i][j];
//			total_s_d += days[i][j];
//			cout << "these will be the seles of day:" << j << days[i][j] << endl;
//
//			if (days[i][j] > large) {
//				large = days[i][j];
//				cout << " the name of the dish is :" << dish[i], 10;
//				cout << " the largest sale of  the dish in the day " << large << endl;
//
//			}
//		}
//
//		total_s_w = total_s_d;
//		cout << "these will be the seles through out the week :" << 7 << total_s_w << endl;
//	}
//
//
//
//
//}
//int main() {
//
//	
//
//	fun();
//
//
//
//
//
//	return 0; 
//
//}