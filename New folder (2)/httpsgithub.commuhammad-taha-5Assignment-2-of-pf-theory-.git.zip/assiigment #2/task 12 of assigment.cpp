#include<iostream>
#include<fstream>
#include <string>
using namespace std;
int add_players(){
	ofstream write("tox.txt",ios::app);
	if (write.is_open ()){
		cout << " opend " << endl;
		char arr[100];
		cout << " enter the recods" << endl;
		cin.getline(arr, 100);
		cout << arr << endl;
		write <<arr<<endl;

	}
	else {
		cout << "closed " << endl;
	}
	return 0;
}
int viwe(){

	ifstream read ("tox.txt");
	if (read.is_open()) {
		cout << " opend " << endl;
		char arr[100];
		while(!read.eof() ){
			read.getline(arr, 100);
		 	cout << arr << endl;
		}
	}
	else {
		cout << "closed " << endl;
	}
	return 0;
}
int search() {

	ifstream read("tox.txt");
	if (read.is_open()) {
		cout << " opend " << endl;
		char arr[100];
		string  arr2_nmae;
		cout << " enter the name of player " << endl;
		cin >> arr2_nmae;
		bool found = false;

		while (!read.eof()) {
			read.getline(arr, 100);

			if (arr == arr2_nmae) {
				found = true;
			}
		}
		if (found = true) {
			cout << " yes found that name " << endl;
		}
		else {
			cout << " not found   invalid name not present  inthe file " << endl;

		}
	}
	else {
		cout << "closed " << endl;
	}

}
int update() {
	ifstream read("tox.txt");
	ofstream write("tox.txt",ios::app);
	bool found = false;
	if (read.is_open()) {
		cout << " opend " << endl;
		char arr[100];
		int runs;
		cout << " enter the runs rate " << endl;
		cin >> runs;
		
		int i = 0;
		int run2 = 0;
		cout << " enter the updataed runs of player " << endl;
		cin >> run2;

		while (!read.eof()){
			read.getline(arr, 100);

			if (arr[i++] == runs) {
				found = true;
				arr[i] = run2;
				write << arr[i];
			}
		}
	}
	else {
		cout << " cloesd " << endl;
	}
	if (found = true) {
		cout << " updated run rate successfully " << endl;
	}
	else {
		cout << " not  uupdated "<< endl;
	}

}
int delelte() {
	ifstream read("tox.txt");
	ofstream write("tox.txt", ios::app);
	bool found = false;
	if (read.is_open()){
		cout << " opend "<<endl;
		string name;
		string s2  = " ";
		cout << " enter the name " << endl;
		cin >> name;

		char arr [100];
		int i=0;
		while (!read.eof()) {
			read.getline(arr, 100); 
			if (arr == name){
				found = true;
				write << s2;
			}
		}
	}
	else {
		cout << " cloesd " << endl;
	}
	if (found = true) {
		cout <<"sucssesfully delted " << endl;
	}
	else {
		cout << " not deleted " << endl;
	}



}
 int main() {
	 
	 cout << " manu of the PSL managment system " << endl;
	 cout << "choice == 1 ,save the record in the file and  add the record of players " << endl;
	 cout << " choice == 2,  viwe all records of players"<<endl;
	 cout << " choice == 3,  search the player name " << endl;
	 cout << " choice == 4, updata  run rate of the player "<< endl;
	 cout << " choice == 5,detet the that player records  " << endl;

	 int num = 0;
	 cout << " enter the choice  \n";
	 cin >> num;
	 if (num ==1){
		 add_players();
	 }else if (num == 2){
		 viwe();
	 }else if (num == 3) {
		 search();
	 }else if (num == 4) {
		 update();
	 }else if (num == 5) {
		 delelte();
	 }
	 else {
		 cout << " you entered the invalid choice "<< endl;
	 }

	return 0;
}