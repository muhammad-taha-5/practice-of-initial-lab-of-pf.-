#include<iostream>
#include<fstream>
using namespace std;
int  fun(ifstream& fun) {
	int arr[10];

	cout << " this the arr";
	for (int i = 0; i < 10; i++) {
		// this is for the getting the arr form the file 
		fun >> arr[i];
		// now cout this arr
		cout << arr[i];
	}
	bool is_prime;
	for (int j = 0; j < 10; j++){
		if (arr[j]%2 == 0|| arr[j] % 3 == 0|| arr[j] % 4==0) {
			is_prime = 0;
			cout << "this not prime" << endl;
		}
		else {
			is_prime = 1;
			cout << "this prime" << endl;
		}
	}


	return 0;
}
int main() {
	ifstream read("dox.txt");




	 fun(read);
	
	return 0;
}
