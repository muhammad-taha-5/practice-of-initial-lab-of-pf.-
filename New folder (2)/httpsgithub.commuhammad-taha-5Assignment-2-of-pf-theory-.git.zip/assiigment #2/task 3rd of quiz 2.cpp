#include<iostream>
using namespace std; 
void reverced (int arr [],int s) {

	arr[s];
	int arr2[10];
	int index = 9;
	for (int i = 0; i < 10; i++) {
		arr2[index--] = arr[i];
	}
	// now for the viwing 
	for (int i = 0; i < 10; i++) {
		cout<< arr2[i];
	}



	
}



int main() {
	int arr[10];
	cout << " enter the arr " << endl;
	for (int i = 0; i < 10;i++ ) {

		cin >> arr[i];
	}



	 reverced(arr, 10);





	return 0;
}
