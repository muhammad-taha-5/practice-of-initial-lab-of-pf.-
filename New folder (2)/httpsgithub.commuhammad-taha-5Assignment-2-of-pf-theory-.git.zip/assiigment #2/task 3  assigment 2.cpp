#include<iostream>
using namespace std;
int count_vowels(string s) {
	int count = 0;
	for (int i = 0; i< s.length(); i++) {

		if (s[i] == 'a'||s[i] == 'e'||s[i] == 'i'|| s[i] == 'o' || s[i] == 'u') {
			count++;
		}

	}
	return count;
}
int main() {
	string s;
	cout << "enter the string " << endl;
	cin >> s;
	cout<<count_vowels(s);

	return 0;
}

