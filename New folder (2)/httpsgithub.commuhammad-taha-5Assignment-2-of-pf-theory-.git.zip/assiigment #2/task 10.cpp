#include<iostream>
using namespace std; 
void fun(int arr2[] ,int a ) {
	arr2[a];
	int arr3[10];
	// now for copiying the arr ;
	for (int i = 0; i < 10; i++) {
		arr3[i] = arr2[i];
	}
	for (int i = 0; i < 10; i++) {
		cout << arr3[i];
	}
}
int main() {
	int arr[10];
	cout << "enter the arr " << endl;
	for (int i = 0; i < 10;i++){
		cin >> arr[i];
	}
	fun(arr, 10);
	return 0;
}