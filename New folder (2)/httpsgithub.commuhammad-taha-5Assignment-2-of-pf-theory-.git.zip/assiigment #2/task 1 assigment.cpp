#include<iostream>
using namespace std;
void  fun(int arr[],int s ) {
	arr[10];
	for (int i = 0; i < 10; i++) {
		cout << arr[i]<< " ";
	
	}
	// now for seeing that arr 
	// this the way to just get and viwe in the same function  
	/*int arr1[5];
	cout << " enter the arr " << endl;
	for (int i = 0; i < 5; i++) {
		cin >> arr1[i];
	}

	for (int i = 0; i <5; i++) {
		cout << arr1[i];
	}*/

}
int main() {
	int arr2[10];
	cout << " enter the arr " << endl;
	for (int i = 0; i < 10; i++){
		cin >> arr2[i];
	}



	fun(arr2,10);
	return 0;
}

