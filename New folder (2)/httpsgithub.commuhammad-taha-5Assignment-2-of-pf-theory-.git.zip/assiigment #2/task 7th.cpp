#include<iostream>
using namespace std;
int count_words( int arr[],int s  ) {
	int count = 0;
	arr[s];
	if (arr[i] == ' '){ count++;}







	return count;
}

int main() {
	int s = 100;
	char arr [100];
	cout << " enter the arr << " << arr << endl;
	cin.getline(arr, 100);

	count_words(arr,s);



	return 0;
}