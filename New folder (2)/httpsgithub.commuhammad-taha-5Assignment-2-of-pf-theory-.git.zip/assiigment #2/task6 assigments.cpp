#include<iostream>
using namespace std;
int pass_arr(int arr[]) {
	arr[10];
	int  largest=arr[0];
	int second_largest=arr[0];
	for (int i = 0; i < 10; i++){
		if (arr[i] > largest){
			second_largest = largest;
			largest = arr[i];

		}
	}
	cout << "this the largest " << largest << endl;
	cout << "this the second largest " << second_largest << endl;
	return largest;
}

int main() {

	int  arr[10];
	int s = 10;

	cout << "enter the  arr " << endl;
	for (int i = 0; i < 10; i++) {
		cin >> arr[i];
	}

	cout<< pass_arr(arr);


	return 0;
}