#include<iostream>
using namespace std; 
int count_greater( int arr [10]){
	int count_G = 0; 
	int count_L = 0;
	int sum = 0; 
	float ave=0; 
	cout << " enter the arr" << endl;
	for (int i = 0; i < 10; i++) {
		cin >> arr[i];
	}

	for (int i = 0; i < 10; i++){
		sum += arr[i];
	}
	cout << " sum :  "<< sum << endl;
	  ave = sum / 10;
	  cout << " this  the average " << ave << endl;

	  for(int i = 0; i < 10; i++){

		  if (arr [i]>ave){
			  count_G++;
		  }
		  else {
			  count_L++;
		  }

	  }
	  cout << "  numbers are greater then  the average   :  " << count_G << endl;
	  cout << " numbers are lesser  then  the average :  " << count_L << endl;








	return  ave; 
 }










int main() {
	int arr[10];
   cout<< 	count_greater(arr);

	return 0; 
}