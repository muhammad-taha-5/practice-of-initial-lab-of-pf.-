#include<iostream>
#include<fstream>
using namespace std;
int add( ){


	ofstream write("student.txt", ios::app);
	char arr[100];
	cout << " enter the whole recod " << endl;
	cin.getline(arr, 100);
	write << endl;
	write << arr;
	cout << "choice = : 1 " << " for adding the mre record in the of student in the file" << endl;
	cout << "enter the choice" << endl;
	write.close();
	return 0;
}


 int viwe(){
	  char arr2[100];
	 ifstream read("student.txt");
	 if (read.is_open()) {
		 cout << " opend this the information of file " << endl;
		 while (!read.eof()) {
			 read.getline(arr2, 100);
			 cout << arr2 << endl;
		 }
	 }
	 else {
		 cout << " closed " << endl;
	 }
	 
	 return 0;
 }

 int srearch(){
	 char arr2[100];
	 ifstream read("student.txt");
	 if (read.is_open()) {
		 cout << " opend this the information of file " << endl;
		 while (!read.eof()) {
			 read.getline(arr2, 100);
			 cout << arr2 << endl;
		 }
// now for searching the
		 int rollnum;
		 cout << " enter the rollnum "<<endl;
		 cin >> rollnum;
		 bool found = false;
		 for (int i = 0; i < 10;i++){
			 if (arr2[i]== rollnum){
				 found = true;
				 break;
		     }
		 }
		 if (found = true){
			 cout<<" found roll number sussesfully "<<endl;
		 }
		 else{
			 cout<<" invalid roll number not found "<<endl;
		 }
		 
	 }
	 return 0;
 }
 int update_gpa(){
	 char arr2[100];
	 ifstream read ("student.txt",ios::app);
	 ofstream write("student.txt", ios::app);
	 if (read.is_open()) {
		 cout << " opend this the information of file " << endl;
		 while (!read.eof()){
			 read.getline(arr2, 100);
			 cout << arr2 << endl;
		 }
		 // now search the cgpa 
		float cgpa = 0;
		 cout << " enter the cgpa "<<endl;
		 cin >> cgpa;
		 bool found = false;
		 float cgpa2;
		 cout << " enter the cgpa"<< endl;
		 cin >> cgpa2;
		 for (int i = 0; i < 10; i++){
			 if (arr2[i] == cgpa){
				 found = true;
				 arr2[i] = cgpa2;
				 write << cgpa2;
				 break;
			 }
		 }
		 read.close();
		 write.close();
	 }
	 else {
		 cout << "closed " << endl;
	 }
	 
	
	 

	 return 0;
 }
 int delite(){

	 char arr2[100];
	 ifstream read("student.txt");
	 ofstream write("student.txt", ios::app);

	 if (read.is_open()){
		 cout << " opend this the information of file " << endl;
	 int num = 0;
	 bool found =false;
	 cout << "enter the roll num  " << endl;
	 cin >> num;
		 while (!read.eof()){
	         int i = 0;
			 read.getline(arr2, 100);
			 if (arr2[i++] == num){
				 found = true;
				 arr2[i++] =' ';
				 write << ' ';//here  this function works for the deteing the record of that person which is  deteed here easily from that file . , no that  line spaces will become printed 
			 }
		 }

	 }
	 else {
		 cout << " not opend" << endl;
	 }

	 return 0;
 }
int main(){

	int option;
	cout << "Student Management System " << endl;
	cout << "1.View All Student Records " << endl;;
	cout << "2. Add Student Record  " << endl;;
	cout << "3. Search Student by Roll Number " << endl;
	cout << "4.Update Student GPA " << endl;
	cout << "5.Delete Student Record " << endl;
	cin >> option;
	if (option < 1 || option >5)
	{
		cout << "Invalid Input ! , Try again\n";
		return 0;
	}
	if (option == 1) { viwe();}// this for the viwing the record .
	else if (option == 2) { add(); }// ths for adding the record .
	else if (option == 3) { srearch(); }// this for the searching with rol number.
	else if (option == 4) { update_gpa();} //this for the updataing the cgpa .
	else if (option == 5) { delite(); } // this for the deteting the rcord of that candidate.
	
	return 0;
}