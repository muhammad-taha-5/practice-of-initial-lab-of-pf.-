#include<iostream>
#include<fstream>
using namespace std; 
int count_vowels(string s) {
	char arr[100]=s;
	for(int i = 0; i < 10; i++ ) {
		cout << arr[i];

	}





	return ;
}

int main() {
	string s;
	cout << "enter the string " << endl;
	cin >> s;
	count_vowels(s);
	cout<<"this the sum of arr" << sum(arr, 10);
	return 0;
}

