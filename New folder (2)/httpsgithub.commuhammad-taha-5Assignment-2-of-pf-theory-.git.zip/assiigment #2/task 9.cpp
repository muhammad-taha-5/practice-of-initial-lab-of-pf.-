#include<iostream>
#include<string>
using namespace std; 
void fun(string arr ){
	 char reverce[100];
	 int index = 0;
	 for (int i = arr[i] = '\0'; arr[i] >= 0; i++){
		 reverce[index++] = arr[i];
	 }
	 // now for the comparing arrs or strings
	 bool same_palandromic = true;
	 for (int i = 0;arr[i]!='\0'; i++) {
		 if (reverce[i] == arr[i]){
			 same_palandromic = false ;
			 cout << " both are not equal " << endl;
		 }
		 else{
			 cout << " both are equal "<< endl;
		 }

	 }
	 if(same_palandromic == false){
		 cout << " this the palandromic" << endl;
	 }
	 else {
		 cout << " this not palandromic" << endl;
	 }

}

int main (){
	string s;
	cout << " enter the stirng " << endl;
	
	fun(s);
	return 0; 
}