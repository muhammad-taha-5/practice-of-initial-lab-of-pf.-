#include<iostream>
using namespace std;
int count_words(char  arr[], int s) {
	arr[s];
	int count = 0;

	for (int i = 0; arr[i] != '\0'; i++) {
		if (arr[i] == ' ' || arr[i] == '.') { count++; }
	}
	cout << count << endl;
	return count;
}

int main() {
	int s = 100;
	char arr[100];
	cout << " enter the arr " << endl;
	cin.getline(arr, 100);

	cout << count_words(arr, s);



	return 0;
}