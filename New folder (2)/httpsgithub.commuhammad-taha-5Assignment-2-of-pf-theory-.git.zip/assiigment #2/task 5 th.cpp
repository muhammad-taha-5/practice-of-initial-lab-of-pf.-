#include<iostream>
#include<fstream>
using namespace std;
void  pass_arr(char(&arr)[100], int &s) {
	arr[s];
	for (int i= 0; i < 100; i++) {
		cout << arr[i] << endl;

	}

}
int main() {
	char arr[100];
	int s = 100;

	cout << "enter the char arr " << endl;
	for (int i = 0; i < s; i++){
		cin >> arr[i];
	}

	pass_arr(arr, s);


	return 0;
}