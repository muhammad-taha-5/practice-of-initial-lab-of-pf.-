                                            // this through other mathode and call by refrence  ; 
#include<iostream>
using namespace std;
int count_vowels(char arr[], int &s) { // here this called by refrence
	int count = 0;
	for (int i = 0; i < s; i++) {
		if (arr[i] == 'a' || arr[i] == 'e' || arr[i] == 'i' || arr[i] == 'o' || arr[i] == 'u' || arr[i] == 'A' || arr[i] == 'E' || arr[i] == 'I' || arr[i] == 'O' || arr[i] == 'U') {

			count++;
		}

	}
	return count;
}
int main() {
	int s;
	char arr[s];

	cout << "enter the char arr[i]" << endl;
	cin.getline(arr, 100);
	while (arr[s] != '0') {
		s++;

	}
	cout << count_vowels(arr, s);

	return 0;
}

