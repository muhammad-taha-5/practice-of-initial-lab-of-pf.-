#include <iostream>
#include <fstream>
using namespace std; 
int main() {
	int num ;
	ofstream odd("odd.txt");
	ofstream even("even.txt");
	ifstream read ("file.txt");
	if (read.is_open() ) {
		while(read>>num){
			cout << num; 
			if (num %2 == 0 ) {
				even  << num;
			}
			else if (num% 2 !=0 ){
				odd << num;

			}


		}




	}
	else {
		cout << " closed" << endl;
	}
	return 0;
}