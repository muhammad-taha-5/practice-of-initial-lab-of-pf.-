//#include <iostream>
//#include <fstream>
//using namespace std;
//
//const int MAX = 100;
//int arr[MAX];
//
// Function declarations
//void growFront(){
//    int s = 5;
//    int* arr = new int[s];
//     Random array
//    cout << "Original array:\n";
//    for (int i = 0; i < s; i++){
//        arr[i] = rand() % 10;
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//
//    int s2;
//    cout << "Enter new total size (greater than " << s << "): ";
//    cin >> s2;
//
//    while (s2 <= s) {
//        cout << "New size must be greater than " << s << ". Enter again: ";
//        cin >> s2;
//    }
//
//    int* newArr = new int[s2];
//    int growCount = s2 - s;
//
//     Take new elements for front
//    cout << "Enter " << growCount << " new elements to insert at front:\n";
//    for (int i = 0; i < growCount; i++){
//        cin >> newArr[i];
//    }
//
//     Copy old elements after new ones
//    for (int i = 0; i < s; i++) {
//        newArr[growCount + i] = arr[i];
//    }
//
//    delete[] arr;
//    arr = newArr;
//
//    cout << "New array:\n";
//    for (int i = 0; i < s2; i++) {
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//
//    delete[] arr;
//}
//
//void  grow_end() {
//    int s = 5; 
//    int * arr = new int[s];
//
//    for (int i = 0; i < s; i++) {
//        arr[i] = rand() % 10;
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//    int s3 =0; 
//     r: 
//    if (s3 <= s  ) {
//    cout << " enter the new size for the grow from the end " << endl; 
//    cin >> s3;
//    goto r;
//
//    }
//    int* arr_new = new int[s3];
//     int grow_c = s2 - s;
//
//    for (int i = s; i < s3; i++){
//         cin >> arr_new[i];         
//    }
//   
//    for (int i = 0; i < s; i++) {
//        arr_new[i] = arr[i];
//    }
//
//    delete[]  arr;
//    arr = arr_new ;
//     
//
//    for (int i = 0; i < s3; i++) {
//      cout<<  arr[i];
//    }
//
//    delete[]  arr;
// }
//
//
//
//void user_define_posi() {
//    int s = 5;
//    int* arr = new int[s];
//
//    for (int i = 0; i < s; i++) {
//        arr[i] = rand() % 10;
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//    int s3 =0;
//r:
//    if (s3 <= s) {
//        cout << " enter the new size for the grow from the end " << endl;
//        cin >> s3;
//        goto r;
//
//    }
//    int s2 = s3 - s;
//    int* arr_new = new int[s3];
//    int  n; 
//
//    cout << " enter the num after that poistion" << endl; 
//    cin >> n; 
//    for (int i = 0; i <= n; i++) {
//        arr_new[i] = arr[i] ;
//    }
//    for (int i = 0; i < s2; i++) {
//        cout << "enter new element: ";
//        cin >> arr_new[n + 1 + i];
//    }
//
//    for (int i = n + 1; i < s; i++) {
//        arr_new[s2 + i] = arr[i];
//    }
//
//    delete[] arr; 
//
//    arr = arr_new;
//
//    for (int i = 0; i < s3; i++) {
//         cout <<  arr_new[i]; 
//    }
//
// 
//
//}
//
//void shrinkFront() {
//    int s = 5;
//    int* arr = new int[s];
//
//    for (int i = 0; i < s; i++) {
//        arr[i] = rand() % 10;
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//
//    int* arr_new = new int[s - 1];
//    for (int i = 1; i < s; i++) {
//        arr_new[i - 1] = arr[i];
//    }
//
//    delete[] arr;
//    arr = arr_new;
//
//    cout << "After shrinking from front: ";
//    for (int i = 0; i < s - 1; i++) {
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//}
//
//
//void shrinkEnd() {
//    int s = 5;
//    int* arr = new int[s];
//
//    for (int i = 0; i < s; i++) {
//        arr[i] = rand() % 10;
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//
//    int* arr_new = new int[s - 1];
//    for (int i = 0; i < s - 1; i++) {
//        arr_new[i] = arr[i];
//    }
//
//    delete[] arr;
//    arr = arr_new;
//
//    cout << "After shrinking from end: ";
//    for (int i = 0; i < s - 1; i++) {
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//}
//void shrinkAtPosition() {
//    int s = 5;
//    int* arr = new int[s];
//
//    for (int i = 0; i < s; i++) {
//        arr[i] = rand() % 10;
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//
//    int pos;
//r:
//    cout << "Enter the position to remove (0 to " << s - 1 << "): ";
//    cin >> pos;
//    if (pos < 0 || pos >= s) {
//        goto r;
//    }
//
//    int* arr_new = new int[s - 1];
//
//    for (int i = 0; i < pos; i++) {
//        arr_new[i] = arr[i];
//    }
//
//    for (int i = pos + 1; i < s; i++) {
//        arr_new[i - 1] = arr[i];
//    }
//
//    delete[] arr;
//    arr = arr_new;
//
//    cout << "After shrinking at position " << pos << ": ";
//    for (int i = 0; i < s - 1; i++) {
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//}
//
//
//int main() {
// 
//    int choice; 
//    cout << " enter the choice  " << endl;
//    cin >> choice; 
//    if (choice == 1) {
//
//        growFront();
//    }
//    else if (choice == 2) {
//        grow_end();
//    }
//    else if (choice == 3) {
//        user_define_posi();
//    }
//    else if (choice == 4) {
//        shrinkFront();
//    }
//    else if (choice == 5) {
//        shrinkEnd();;
//    }
//    else if (choice == 6) {
//        shrinkAtPosition();
//    }
//    else if (choice == 7) {
//
//    }
// 
//    return 0;
//}

//                                                                    //  task  # 2
//#include <iostream>
//#include <fstream>
//using namespace std;
//int   r = 5;
//int  const c = 7;
//
//
//void row_f_grow() {
//  
//    
//    // now for making the 2d dynamic arr 
//    int** arr = new  int*[r];
//    for (int i = 0; i < r; i++) {
//        arr[i] = new int[c];
//
//    } 
//
//    cout << " before " << endl;
//    for (int i = 0; i < r; i++ ) {
//        for (int j = 0; j < c;  j++ ){
//            arr[i][j] = rand() % 10; 
//            cout << arr[i][j]; 
//         }
//        cout << endl;
//
//     }
//
//
//    int r2;
//    cout << " enter the rows" << endl;
//    cin >> r2;
//    int** arr2 = new  int* [r2];
//    for (int i = 0; i < r2; i++) {
//        arr2[i] = new int[c];
//
//    }
//
//   
//   
//    cout << endl; cout << endl;
//
//   delete[]  arr;
//   arr = arr2;
//
//   cout << endl; cout << "after"<< endl;
//   for (int i = 0; i < r2; i++) {
//       for (int j = 0; j < c; j++) {
//           arr2[i][j] = rand() % 10;
//           cout << arr2[i][j];
//       }
//       cout << endl;
//   }
//
// }
//
//void grow_last() {
//   
//    int** arr = new  int* [r];
//    for (int i = 0; i < r; i++) {
//        arr[i] = new int[c];
//
//    }
//
//    int temp[100];  
//    cout << "Enter values for new row: ";
//    for (int j = 0; j < c; j++) {
//        cin >> temp[j];
//    }
//    r = 0;
//    for (int j = 0; j < c ; j++) {
//
//        arr[r][j] = temp[j];
//    }
//
//    r++;
//
//    cout << "After adding row at end:" << endl;
//    for (int i = 0; i < r; i++) {
//        for (int j = 0; j < c; j++) {
//            cout << arr[i][j] << " ";
//        }
//        cout << endl;
//    }
//}
//
//void grow_user() {
//
//    int** arr = new  int* [r];
//    for (int i = 0; i < r; i++) {
//        arr[i] = new int[c];
//
//    }
//    int temp;
//    cout << "enter the position where to insert new row: ";
//    cin >> temp;
//
//    if (temp < 0 || temp > r) {
//        cout << "invalid position" << endl;
//        return;
//    }
//
//    for (int i = r; i > temp; i--) {
//        for (int j = 0; j < c; j++) {
//            arr[i][j] = arr[i - 1][j];
//        }
//    }
//
//    cout << "enter values of new row: ";
//    for (int j = 0; j < c; j++) {
//        cin >> arr[temp][j];
//    }
//
//    r++;
//
//    for (int i = 0; i < r; i++) {
//        for (int j = 0; j < c; j++) {
//            cout << arr[i][j] << " ";
//        }
//        cout << endl;
//    }
//}
//
//
//
//
//
//
//void shrink_front() {
//
//    int** arr = new  int* [r];
//    for (int i = 0; i < r; i++) {
//        arr[i] = new int[c];
//
//    }
//
//    cout << " before " << endl;
//    for (int i = 0; i < r; i++) {
//        for (int j = 0; j < c; j++) {
//            arr[i][j] = rand() % 10;
//            cout << arr[i][j];
//        }
//        cout << endl;
//
//    }
//    if (r == 0) {
//        cout << "no row to remove" << endl;
//        return;
//    }
//
//    for (int i = 0; i < r - 1; i++) {
//        for (int j = 0; j < c; j++) {
//            arr[i][j] = arr[i + 1][j];
//        }
//    }
//
//    r--;
//
//    for (int i = 0; i < r; i++) {
//        for (int j = 0; j < c; j++) {
//            cout << arr[i][j] << " ";
//        }
//        cout << endl;
//    }
//}
//
//
//void shrink_last() {
//
//    int** arr = new  int* [r];
//    for (int i = 0; i < r; i++) {
//        arr[i] = new int[c];
//
//    }
//
//    cout << " before " << endl;
//    for (int i = 0; i < r; i++) {
//        for (int j = 0; j < c; j++) {
//            arr[i][j] = rand() % 10;
//            cout << arr[i][j];
//        }
//        cout << endl;
//
//    }
//    if (r == 0) {
//        cout << "no row to remove" << endl;
//        return;
//    }
//
//    r--;
//
//    for (int i = 0; i < r; i++) {
//        for (int j = 0; j < c; j++) {
//            cout << arr[i][j] << " ";
//        }
//        cout << endl;
//    }
//}
//
//void shrink_user_pos() {
//
//    int** arr = new  int* [r];
//    for (int i = 0; i < r; i++) {
//        arr[i] = new int[c];
//
//    }
//
//    cout << " before " << endl;
//    for (int i = 0; i < r; i++) {
//        for (int j = 0; j < c; j++) {
//            arr[i][j] = rand() % 10;
//            cout << arr[i][j];
//        }
//        cout << endl;
//
//    }
//    int temp;
//    cout << "enter the position to remove: ";
//    cin >> temp;
//
//    if (temp < 0 || temp >= r) {
//        cout << "invalid position" << endl;
//        return;
//    }
//
//    for (int i = temp; i < r - 1; i++) {
//        for (int j = 0; j < c; j++) {
//            arr[i][j] = arr[i + 1][j];
//        }
//    }
//
//    r--;
//
//    for (int i = 0; i < r; i++) {
//        for (int j = 0; j < c; j++) {
//            cout << arr[i][j] << " ";
//        }
//        cout << endl;
//    }
//}
//
//int main() {
//
//        int choice; 
//        cout << " enter the choice  " << endl;
//        cin >> choice; 
//        if (choice == 1) {
//            row_f_grow();
//        }
//        else if (choice == 2) {
//            grow_last () ;
//
//        }
//        else if (choice == 3) {
//            grow_user();
//        }
//        else if (choice == 4) {
//            shrink_front();
//        }
//        else if (choice == 5) {
//            shrink_last();
//        }
//        else if (choice == 6) {
//            shrink_user_pos();
//        }
//        else {
//            cout << "  not made the filing because of I am   tired  alot   " << endl; 
//        }
//     
//    return 0;
//}




                                                                                                        ///task  #3 
#include <iostream>
#include <fstream>
using namespace std;

const int MAX = 100;
int* arr[MAX];
int col[MAX]; // stores number of columns per row
int rows = 0;

void saveToFile(const char* fname) {
    ofstream out(fname);
    if (out.is_open()) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < col[i]; j++) {
                out << arr[i][j];
                if (j != col[i] - 1) out << ",";
            }
            out << endl;
        }
        out.close();
    }
}

void grow_front() {
    int* temp[MAX];
    int temp_col[MAX];
    for (int i = rows; i > 0; i--) {
        temp[i] = arr[i - 1];
        temp_col[i] = col[i - 1];
    }
    int c;
    cout << "Enter number of columns for new front row: ";
    cin >> c;
    temp[0] = new int[c];
    temp_col[0] = c;
    cout << "Enter elements: ";
    for (int j = 0; j < c; j++) {
        cin >> temp[0][j];
    }
    rows++;
    for (int i = 0; i < rows; i++) {
        arr[i] = temp[i];
        col[i] = temp_col[i];
    }
}

void grow_end() {
    int c;
    cout << "Enter number of columns for new last row: ";
    cin >> c;
    arr[rows] = new int[c];
    col[rows] = c;
    cout << "Enter elements: ";
    for (int j = 0; j < c; j++) {
        cin >> arr[rows][j];
    }
    rows++;
}

void grow_user() {
    int temp[MAX];
    int* new_arr[MAX];
    int new_col[MAX];
    int temp1;
    cout << "Enter the row number where to insert: ";
    cin >> temp1;
    int c;
    cout << "Enter number of columns for new row: ";
    cin >> c;
    new_arr[temp1] = new int[c];
    new_col[temp1] = c;
    cout << "Enter elements: ";
    for (int j = 0; j < c; j++) {
        cin >> new_arr[temp1][j];
    }

    for (int i = 0; i < temp1; i++) {
        new_arr[i] = arr[i];
        new_col[i] = col[i];
    }
    for (int i = temp1 + 1; i <= rows; i++) {
        new_arr[i] = arr[i - 1];
        new_col[i] = col[i - 1];
    }
    rows++;
    for (int i = 0; i < rows; i++) {
        arr[i] = new_arr[i];
        col[i] = new_col[i];
    }
}

void shrink_front() {
    delete[] arr[0];
    for (int i = 1; i < rows; i++) {
        arr[i - 1] = arr[i];
        col[i - 1] = col[i];
    }
    rows--;
}

void shrink_end() {
    delete[] arr[rows - 1];
    rows--;
}

void shrink_user() {
    int temp1;
    cout << "Enter the row number to delete: ";
    cin >> temp1;
    delete[] arr[temp1];
    for (int i = temp1 + 1; i < rows; i++) {
        arr[i - 1] = arr[i];
        col[i - 1] = col[i];
    }
    rows--;
}

void show() {
    cout << "Current jagged array:\n";
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < col[i]; j++) {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int r;
    cout << "Enter initial number of rows: ";
    cin >> r;
    rows = r;
    for (int i = 0; i < rows; i++) {
        cout << "Enter number of columns for row " << i << ": ";
        cin >> col[i];
        arr[i] = new int[col[i]];
        cout << "Enter elements: ";
        for (int j = 0; j < col[i]; j++) {
            cin >> arr[i][j];
        }
    }

    saveToFile("original_jagged.txt");

    int ch;
    do {
        cout << "\nMenu:\n";
        cout << "1. Grow from Front\n";
        cout << "2. Grow from End\n";
        cout << "3. Grow at User-Defined\n";
        cout << "4. Shrink from Front\n";
        cout << "5. Shrink from End\n";
        cout << "6. Shrink from User-Defined\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> ch;

        switch (ch) {
        case 1: grow_front(); break;
        case 2: grow_end(); break;
        case 3: grow_user(); break;
        case 4: shrink_front(); break;
        case 5: shrink_end(); break;
        case 6: shrink_user(); break;
        }

        if (ch >= 1 && ch <= 6) {
            saveToFile("updated_jagged.txt");
            show();
        }

    } while (ch != 0);

    return 0;
}
