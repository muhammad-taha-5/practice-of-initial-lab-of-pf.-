//
//#include<iostream> 
//#include<fstream>
//
//using namespace std; 
//
//
//
//
//	//
//	//
//	//void create() {
//	//	int i, j;
//	//	int const r = 5;
//	//	int col[r];
//	//
//	//	
//	//	// now for the declering the jegged arr in the dynamic form 
//	//	// now for getting the colums from usre
//	//	int** arr = new int* [r];
//	//	for (i = 0; i < col[i]; i++) {
//	//		cout << "enter the coloum in the rows from 1st to " << i + 1 << endl;
//	//		cin >> col[i];
//	//		arr[i] = new  int[col[i]];
//	//	}
//	//
//	//	int index = 1;
//	//	for (i = 0; i < r; i++) {
//	//		cout << " enter the  values " << i << endl;
//	//		for (j = 0; j < col[i]; j++) {
//	//			cout << " enter the  values in the col  " << index++ << endl;
//	//			cin >> arr[i][j];
//	//		}
//	//	}
//	//	outs(r, col, arr);
//	//}
//	//
//	//
//	//
//	//
//	//
//	//
//	//
//	//
//	//
//	//int main(){
//	//
//	////	//int const r = 5;
//	////	//int c = 5;
//	////	//int** arr= new  int* [r];
//	////	//for (int i = 0; i < r;i++ ) {
//	////	//	arr[i] = new int[c];
//	////	//}
//	////
//	////	//// putinng the values in the arr by the rannd ();
//	////
//	////	//	for (int i = 0; i < r; i++) {
//	////	//	  for (int j = 0; j < c; j++) {
//	////	//		arr[i][j] = rand() % 20;
//	////	//	  }
//	////	//     }
//	////	//	int index = 0;
//	////	//	int arr2[10] = { 0 };
//	////	//	for (int i = 0; i < r; i++) {
//	////	//		for (int j = 0; j < c; j++) {
//	////	//			cout << arr[i][j] << " ";
//	////	//			write << arr[i][j] << " ";
//	////
//	////	//			if (i==j) {
//	////	//				arr2[index++] = arr[i][j];
//	////	//			}
//	////	//		}
//	////	//		cout << " " << endl;
//	////	//		write << " " << endl;
//	////	//	}
//	////
//	////	//	cout << " " << endl;
//	////	//	cout << " " << endl;
//	////	//	for (int i = 0; i < 10; i++) {
//	////	//		cout << arr2[i]<<  " " ;
//	////	//	}
//	////	//	cout << " " << endl;
//	////	//	cout << " " << endl;
//	////	//	  // now some thig new 
//	////	//	index = 0;
//	////
//	////	//	int arr3[10] = { 0 };
//	////	//	for (int j = 0; j < c; j++) {
//	////	//    	for (int i = 0; i < r; i++) {
//	////	//		
//	////	//			cout << arr[i][j] << " ";
//	////	//			write << arr[i][j] << " ";
//	////
//	////	//			if (i == j){
//	////	//				arr3[index++] = arr[i][j];
//	////	//		
//	////	//			}
//	////	//		}
//	////	//		cout << " " << endl;
//	////	//		write << " " << endl;
//	////	//	}
//	////	//	cout << " " << endl;
//	////	//	cout << " " << endl;
//	////	//	for (int i = 0; i < 10; i++) {
//	////	//		cout << arr3[i] << " ";
//	////	//	}
//	////
//	////
//	////	
//	////
//	////	 //
//	////		//ifstream read("dox.txt");
//	////		//int const r2 =3;
//	////		//int const c2 = 3; 
//	////		//if (r2 == c2){
//	////
//	////		//	int** arr3 = new int* [r2];
//	////		//	for (int i = 0; i < r2; i++) {
//	////		//		arr3[i] = new int[c2];
//	////		//	}
//	////
//	////		//	for (int i = 0; i < r2; i++) {
//	////		//		for (int j = 0; j < c2; j++) {
//	////		//			read >> arr3[i][j];
//	////		//		}
//	////		//	}
//	////
//	////		//	for (int i = 0; i < r2; i++) {
//	////		//		for (int k = 0; k < c2; k++) {
//	////		//			cout << arr3[i][k] << " ";
//	////		//		}
//	////		//		cout << endl;
//	////		//	}
//	////
//	////		//	//now for reading the 2nd one matix 
//	////		//	int** arr4 = new int* [r2];
//	////		//	for (int i = 0; i < r2; i++) {
//	////		//		arr4[i] = new int[c2];
//	////		//	}
//	////		//	// read  the file  the 2nd arr 
//	////		//	for (int i = 0; i < r2; i++) {
//	////		//		for (int j = 0; j < c2; j++) {
//	////		//			read >> arr4[i][j];
//	////		//		}
//	////		//	}
//	////		//	//  cout 
//	////		//	for (int i = 0; i < r2; i++) {
//	////		//		for (int k = 0; k < c2; k++) {
//	////		//			cout << arr4[i][k] << " ";
//	////		//		}
//	////		//		cout << endl;
//	////		//	}
//	////		//	int** multi = new int*[r2];
//	////		//	for (int i = 0; i < r2; i++ ){
//	////		//		multi[i] = new int[c2];
//	////
//	////		//	}
//	////		//	// now multipli 
//	////		//	for (int i = 0; i < r2; i++){
//	////		//		for (int k = 0; k < c2; k++){
//	////		//			multi[i][k] = arr3[i][k] * arr4[i][k];
//	////		//		}
//	////		//		cout << endl;
//	////		//	}
//	////		//	cout << endl;
//	////		//	cout << endl;
//	////		//	// now multipli 
//	////		//	for (int i = 0; i < r2; i++) {
//	////		//		for (int k = 0; k < c2; k++) {
//	////		//			cout << multi[i][k]<<" ";
//	////		//		}
//	////		//		cout << endl;
//	////		//	}
//	////
//	//// //// now for the jegged arr 
//	//// //int r = 5; 
//	//// //int c = 20;
//	//// //ifstream read("dox.txt");
//	////
//	//// ////  dynamically arr
//	//// // char ** arr = new char*[r]; 
//	//// // for (int i = 0; i < r; i++) {
//	////	// arr[i] = new char[c];
//	//// // }
//	//// // ofstream write("dogs.txt");
//	//// // for (int i = 0; i < r; i++) {
//	////	//
//	////	//	  read.getline(arr[i], c, '\n');
//	////	//	  cout << arr[i]<< endl;
//	//// // }
//	////
//	////
//	//create();
//	//	                                                   ////// now for the jegged arr 
//	//	return 0;
//	//}
//
//	void  outs(int r2, int* col2, int** arr2) {
//		r2;
//		arr2;
//		col2;
//		ofstream write("dox.txt");
//		for (int i = 0; i < r2; i++) {
//			for (int j = 0; j < col2[i]; j++) {
//				cout << arr2[i][j] << " ";
//				write << arr2[i][j] << " ";
//			}
//			cout << endl;
//			write << endl;
//		}
//	}
//	////// now the growing the array 
//
//
//	void create() {
//
//		int  i, j;
//		int const  r = 5;
//
//		int col[r];
//
//		int** arr = new  int* [r];
//		for ( i = 0; i < r; i++) {
//			cout << " enter the col of rows " << i + 1 << endl;
//			cin >> col[i];
//			arr[i] = new int[col[i]];
//		}
//
//		for ( i = 0; i < r; i++) {
//			for ( j = 0; j < col[i]; j++) {
//				cout << " arr[" << i << "][" << j << "]" << endl;
//				cin >> arr[i][j];
//
//			}
//
//		}
//		cout << " before   updating " << endl;
//
//		outs(r, col, arr);
//		row:
//		int r_to_ch;
//		cout << " enter the row to change " << endl;
//		cin >> r_to_ch;
//		if (r_to_ch > r || r_to_ch < 0 ) {
//			  
//		goto row;
//		}
//		co:
//		int newcol; 
//		cout << " enter the new colums " << endl;
//		cin >> newcol;
//
//		  // now for the verifing the new col
//
//		 if(newcol < col[r_to_ch -1] ) {       // new col are lesser then previous the  take colums again
//			 goto co;
//		 }
//		  
//
//		 int* arr3 = new int[newcol];
//
//		 for ( i = 0; i < col[r_to_ch - 1]; i++){
//
//			 arr3[i]= arr[r_to_ch - 1][i];
//
//			 cout << arr3[i] <<endl;
//		 }
//		 
//		
//		 for ( i = col[r_to_ch - 1]; i < newcol; i++) {
//			 cout << " ener the values at next index" << i << endl;
//			cin>> arr3[i];
//		 }
//
//		 col[r_to_ch - 1] = newcol;
//
//		 delete[]  arr[r_to_ch - 1];
//
//		 arr[r_to_ch - 1] = arr3;
//
//
//		 cout << "after  updating " << endl;
//		 outs(r, col, arr);
//
//	}
//
//
//
//
//
//	int main() {
//
//		create();
//
//
//
//
//
//
//		return  0;
//
//	}
