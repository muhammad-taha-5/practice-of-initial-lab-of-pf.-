#include<iostream>
using namespace std;
int main() {
	int s = 5;
	char* arr = new   char[s];
	for (int i = 0; i < s; i++ ) {
		cout << " enter the upper and lower also " << i << endl;
		cin >> arr[i];
	 }

	 char arr2[3];
	bool fund = false; 
	int index = 0;
	  // now for the comperssion of the alphabate
	
	for ( int i = 0; i < s; i++ ) {
		for (int j = 0; j < s; j++) {
			if (arr[i] > 'A' && arr[i] < 'z') {
				if (i != j && arr[i]== arr[j]+32 ) {
					fund = true ;
					arr2[index++] = arr[i];
					arr2[index++] = (arr[j]);

				 }
			}
		}
	}
		cout << " this  the arr in which elements found matched ";
	for (int i = 0; i < s; i++) {
		cout << arr2[i];
	 }









	return 0; 
}