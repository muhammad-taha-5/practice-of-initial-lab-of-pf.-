#include <iostream>
#include<fstream>
using namespace std;
int fun(int* arr, int s) {
	arr[s];
	
	bool found = false;
	int freq;
	for (int i = 0; i < 13; i++) {
		found = false;

		for (int j = i+1; j < 14; j++) {

			if (arr[i] == arr[j]) {
				found = true;
				break;
			}
			
		
		}
		if (found == false){
			cout << arr[i]<< " ";
		}
		
	}
	cout << endl;
	

	return 0;
}
int main() {
	int arr[10];

	ifstream read("dox.txt");
	for (int i = 0; i < 14; i++) {
		read >> arr[i];

	}
	
	fun(arr, 14);

	return 0;
}