#include<iostream>
#include<fstream>
using namespace std;
int  fun(int* arr, int& s) {
	arr[s];
	int* p1 = arr;
	for (int i = 0; i < s; i++) {
		cout << *(p1 + i);
	}
	int key;
	bool fund = false;
	int greater = INT_MAX;
	cout << " enter the key " << endl;
	cin >> key;
	int index=0; 
	for (int i = 0; i < 10; i++){
		if (arr[i] == key){
			fund = true;
			index = i;
			return index;
			 
		}
		else {
			if (arr[i - 1] > arr[i + 1]) {
				index = i - 1;

			}
			else {
				index = i + 1;

			}
		}
		 
	}
	

	


	return index ;
}
int main() {
	ifstream read("dox.txt");
	int arr[10];
	int i;

	for (i = 0; !read.eof(); i++) {
		read >> arr[i];
		cout << " arr" << arr[i];

	}

	cout << endl;
	cout << i << endl;

	 cout << fun(arr, i);
	return 0;
}
