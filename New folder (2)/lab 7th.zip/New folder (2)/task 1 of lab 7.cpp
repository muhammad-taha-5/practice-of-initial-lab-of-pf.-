#include<iostream>
#include<fstream>
using namespace std; 
void fun (int *arr ,int &s ){
	arr[s];
	int* p1 = arr; 
	for (int i = 0; i < s; i++) {
		cout << * (p1 + i);
    }
	int key;
	bool fund = false; 
	cout << " enter the key " << endl;
	cin >> key; 
	for (int i= 0; i < 10 ; i++ ){
		if (arr[i]== key){
			fund = true; 

			for (int j = i; j < 9; j++) {
				arr[j] = arr[j + 1];
			}
		
			
		}
		
	 } 
	for (int j = 0; j < 10; j++) {
		cout << arr[j];
	}



}
int main() {
	ifstream read("dox.txt");
	int arr[10];
	int i;

	for ( i = 0; !read.eof() ; i++) {
		read >> arr[i];
		cout << " arr" << arr[i];

	}

	cout << endl;
	cout << i << endl;

	fun(arr, i);
	return 0; 
}
