#include <iostream>
#include<fstream>
using namespace std; 
void  sum(int *arr, int s) {
	arr[s];
	int *p1 = arr;
	int sum = 0; 
	for(int i = 0; i <  10 ; i++) {
               // sum +=arr[i]; // it other methode  
		sum += *(p1+i);
		
	}
	cout << sum;



	
}
int main() {
	ifstream read("dox.txt");
 
	int arr[10];
	int i= 0; 
	while (!read.eof () ) {
		read >> arr[i];
		cout << arr[i] << endl;
		i++;
	}



	  sum(arr, 9);
	return 0; 
}