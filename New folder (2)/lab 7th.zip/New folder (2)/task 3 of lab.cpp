#include< iostream>
#include<fstream>
using namespace std;
void fun(int *arr ){
	int arr2 [5];
	arr[13]; 
	int s = 13;
	int index = 0; 
	int c = 0;
	// now cout<< " 56789"
	for (int i = 0 ; i < s; i++){
		c = 0;  
		for (int j =0; j < s; j++){
			if (arr[i] == arr[j]){
				c ++;
				
			}
			
		}
		if (c==1){
			arr2[index++] = arr[i];
		}
		
	}
	for (int i = 0; i < index; i++ ){
		cout << arr2[i];
	}

}

int main() {
	ifstream read ("dox.txt");
	 
	int s; 
	read >> s;
	// dynamic arr  of memory 
		int *arr = new int [s];
		 
		// now for reading the arr form file
		for (int i = 0; i < s; i++ ) {
			read >> arr[i];

		}

		
		fun( arr );


	return 0; 
}