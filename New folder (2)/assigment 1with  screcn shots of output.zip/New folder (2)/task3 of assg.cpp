#include< iostream>
#include< fstream>
using namespace std;
int main() {

	ofstream write("dox.txt", ios::app);
	if (write.is_open()) {
		 write << " and these both are from khuwaja muhala khuhra" << endl;
		//cout << "open " << endl;
		 cout<<"your extra modified info was transformaed susscesfully"<<endl;
	}
	else {
		cout << " closed" << endl;
	}








	return 0;
}