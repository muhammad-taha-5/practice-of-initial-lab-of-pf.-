#include<iostream>
#include<fstream>
using namespace std;
int main() {

	int count = 0;
	char arr[1000];
	ifstream read("dox.txt");
	read.getline(arr, 100);
	cout << arr;


	if (read.is_open()) {

		for (int i = 0; arr[i] != '\0'; i++) {
			if (arr[i] == ' ') {
				count++;
			}

		}
		cout << endl;
		count += 1;
	}
	else {
		cout << " closed" << endl;
	}


	cout << " this the count word   : " << count << endl;

	system("pause");
	return 0;
}