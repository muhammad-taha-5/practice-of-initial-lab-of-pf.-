#include<iostream>
#include<fstream>
#include<string>

using namespace std;
int main()
{
    string filename = ("info.txt");
    string newLine;
    int lineNumber;

    cout << "Enter Line number to change: ";
    cin >> lineNumber;

    cout << "Enter new Line: ";
    cin.ignore();
    getline(cin, newLine);

    ifstream file("in.txt");
    ofstream temp("temp.txt",ios::app);
    string line;
    int count = 1;

    while (getline(file, line))
    {
        if (count == lineNumber) 
        {
            temp << newLine << endl;
        }
        else
        {
            temp << line << endl;
        }
            count++;
    }

    file.close();
    temp.close();

    remove(filename.c_str());
    rename("temp.txt", filename.c_str());

    cout << "Line updated successfully!" << endl;

    return 0;
}