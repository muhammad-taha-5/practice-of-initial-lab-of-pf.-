#include< iostream>
#include< fstream>
using namespace std;
int main() {
	ofstream write("dox.txt");
	char name[100];
	cout << " enter your name " << endl;
	cin.getline(name, 100);
	int age = 0; 
	cout << " enter your age  " << endl;
	cin >> age; 

	if (write.is_open()){
		write << name << " : " << age << endl;

	}
	else {
		cout << " closed " << endl;
	}









	return 0;
}