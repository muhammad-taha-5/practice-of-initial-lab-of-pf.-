#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main() {
	string s, st;
	char arr[100];
	ifstream read("doxss.txt");
	ofstream write("doxss.txt",ios::app);

	char enter[100];
	read.getline(arr ,100,'\n');
	cout << arr << endl;

	 read.getline(arr, 100, '\n');
	cout << arr << endl;

	read.getline(arr, 100, '\n');
	cout << arr << endl;

	read.getline(arr, 100, '\n');
	cout << arr << endl;
	
	read.getline(arr, 100);
	cout << arr << endl;
	

	cout << " enter in the given arr for adding in the table of marks sheet " << endl;
	cin.getline(enter, 100);
	ofstream wr("dox.txt");
	if (wr.is_open()){
		cout << " opened " << endl;
		write << enter;
		wr << enter;
	}
	else {
		cout << " closed" << endl;
	}

	//now for searching roll num 
	
	cout << " enter the string as roll num " << endl;
	cin >> s; 

	ifstream re ("dox.txt" );
	re >> st;
	cout << st;
	if (re.is_open()){

		if ( st == s){// search roll num 
			cout << " yes found the roll num number "<< endl;
			cout << st << endl;
		}
		else {
			cout << "  not  found the  " << endl;
		}

	}
	else {
		cout << " closed" << endl;
	}













	
	return 0;
}