#include <fstream>
#include <iostream>
#include <string>

using namespace std;

int main()
{
    string text;
    cout << "Enter text to encrypt   thanks : ";
    cin.ignore();
    getline(cin, text);

    ofstream file("secure.txt");
    for (int i = 0; i < text.length(); i++) {
        file << (char)(text[i] + 3);
    }
    file.close();

    cout << "Text encrypted and written to secure.txt." << endl;

    ifstream file2("secure.txt");
    string decryptedText;
    char c;
    while (file2.get(c)) {
        decryptedText += (char)(c - 3);
    }
    file2.close();

    cout << "Decrypted text: " << decryptedText << endl;

}