#include <fstream>
#include <iostream>
#include <string>

using namespace std;
int main()
{
    string filename = "input.txt";
    int choice;
    string text;
    int lineNumber;
    string newLine;

    while (true)
    {
        cout << "---Database Management System---" << endl;
        cout << "1. Add text to file" << endl;
        cout << "2. Read from file" << endl;
        cout << "3. Update line in file" << endl;
        cout << "4. Delete record" << endl;
        cout << "5. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1)
        {

            ofstream file("input.txt");
            cout << "Enter Text to add: ";
            cin.ignore();
            getline(cin, text);

            file << text << endl;
            file.close();

            cout << "Text added Successfully!" << endl;
        }

        else if (choice == 2)
        {
            ifstream file("input.txt");
            string line;

            if (file.is_open())
            {
                while (getline(file, line))
                {
                    cout << line << endl;
                    cout << endl;
                }
                file.close();
            }
            else
            {
                cout << "File not found!" << endl;
            }
        }

        else if (choice == 3)
        {

            ifstream file2("database.txt");
            ofstream temp("temp.txt");
            string line2;

            cout << "Enter Line Number to Update: ";
            cin >> lineNumber;

            cout << "Enter New Line: ";
            cin.ignore();
            getline(cin, newLine);

            int count = 1;

            while (getline(file2, line2))
            {
                if (count == lineNumber)
                {
                    temp << newLine << endl;
                }
                else
                {
                    temp << line2 << endl;
                }
                count++;
            }

            file2.close();
            temp.close();

            remove(filename.c_str());
            rename("temp.txt", filename.c_str());

            cout << "Line updated successfully!" << endl;
        }
        else if (choice == 4)
        {
            cout << "Enter Line Number to Delete: ";
            cin >> lineNumber;

            ifstream file3(filename);
            ofstream temp2("temp.txt");
            string line3;
            int count2 = 1;

            while (getline(file3, line3))
            {
                if (count2 != lineNumber)
                {
                    temp2 << line3 << endl;
                }
                count2++;
            }

            file3.close();
            temp2.close();

            remove(filename.c_str());
            rename("temp.txt", filename.c_str());

            cout << "Deleted successfully!" << endl;
        }

        else if (choice == 5)
        {
            return 1;
        }
        else
        {
            cout << "Invalid choice. Please try again." << endl;
        }
    }
    return 0;
}