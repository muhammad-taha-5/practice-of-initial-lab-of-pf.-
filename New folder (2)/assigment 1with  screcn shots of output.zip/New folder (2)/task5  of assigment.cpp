#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main() {

	string s;
	cout << "enter thee word to do search for  " << endl;
          cin>> s ;
	ifstream read("dox.txt");
	read >> st;
	if (read.is_open()) {
		if (s == st ) {
			cout << " yes this word found in the file" << endl;
		}
		else {
			cout << " not found " << endl;
		}

		cout << " opend" << endl;
	}
	else {
		cout << " closed" << endl;
	}













	system("pause");
	return 0;
}