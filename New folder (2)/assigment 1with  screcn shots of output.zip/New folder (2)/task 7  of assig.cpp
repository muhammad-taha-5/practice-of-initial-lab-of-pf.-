#include < iostream>
#include <fstream>
#include <string>
using namespace std; 
int main() {

	char arr[100];
	// now  reading this info form source file  
	ifstream  read ("copy.txt");
	read.getline(arr ,100);
	cout << arr << endl;
	// now writting that data into the file destinatio  at the addrass of  destiation.txt // file by M TAHA khuwaja 


	ofstream write ("destination.txt");
	write << arr;

	 
	cout << " this the information is copyed  sussccesfully " << endl;









	return 0;
}

