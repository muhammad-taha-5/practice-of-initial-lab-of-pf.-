#include< iostream>
#include< fstream>
using namespace std;
int main() {
	ifstream read ("dox.txt");
	char name[1000];
	read.getline(name, 1000);
	
	if (read.is_open()) {
	
		cout << "this the info in the txt file " << endl;
		cout << name << endl;

	}else {
		cout << " closed " << endl;
	}









	return 0;
}