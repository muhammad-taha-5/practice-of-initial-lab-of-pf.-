#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main() {
	int x[10];
	int n;
	cout << "enter the num " << endl;
	cin >> n;
	ifstream read ("ave.txt");
	 


	if (read.is_open()) {
		for (int i = 0; i < 10; i++) {
			read >> x [i];
			cout << x[i];
		}
		cout << "open " << endl;
	}
	else {
		cout << " closed" << endl;
	}

	ofstream write("ave.txt");
	if (write.is_open()) {

		write << n <<" ";

        for (int i = 0; i < 1; i++) {
			write << x[i];
			
		}
	}
	else {
		cout << " closed" << endl;
	}




	return 0;
}