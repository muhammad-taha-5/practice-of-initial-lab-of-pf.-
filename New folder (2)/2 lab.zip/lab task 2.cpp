#include<iostream>
#include<fstream>
using namespace std;
int main() {
	float sum = 0;
	float  ave = 0;
	int n = 0;
	int arr[10];
	ifstream read("dogs.txt");
	ofstream write("result.txt");
	if (read.is_open() ){
		for (int i = 0; i <= 5; i++) {
			read >> arr[i];
			sum += arr[i];

		}
	}
	else {

		cout<< " closed"<<endl;
	}


	
	ave = sum / 5;
	write << " this the sum : " << sum << endl;
	write << " this the ave " << ave << endl;

	cout << " this the sum : " << sum << endl;
	cout << " this the ave " << ave << endl;

	system("pause");

	return 0;
}