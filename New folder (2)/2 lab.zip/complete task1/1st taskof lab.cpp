#include <iostream>
#include<fstream>
#include < string>
using namespace std;
int main() {

	int a;
	ifstream fin("intiger.txt");

	fin >> a;
	cout << a;
	fin.close();
	cout << endl;

	int b;
	ifstream read("double.txt");
	read >> b;
	cout << b;
	read.close();

	cout << " " << endl;
	int c;
	ifstream re("boolean.txt");
	re >> c;
	cout << c;
	re.close();

	cout << " " << endl;
	float d;
	ifstream rea("float.txt");
	rea >> d;
	cout << d;
	rea.close();


	// now for characters 
	cout << " " << endl;
	char ch;
	ifstream reada("char.txt");
	reada >> ch;
	cout << ch;
	reada.close();


	// characterArray.txt
	// now for characters arr 
	cout << endl;
	char arr[100];
	ifstream reaad("characterArray.txt");
	reaad.getline(arr, 100);
	cout << arr;
	reaad.close();


	cout << endl;
	// nowfor writting 

	ofstream write("newfile.txt");

	if (write.is_open()) {
		fin >> a;
		write << a;
		fin.close();
		write << endl;

		int b;
		ifstream read("double.txt");
		read >> b;
		write << b;
		read.close();

		write << " " << endl;
		int c;
		ifstream re("boolean.txt");
		re >> c;
		write << c;
		re.close();

		write << " " << endl;
		float d;
		ifstream rea("float.txt");
		rea >> d;
		write << d;
		rea.close();

		// now for characters 
		write << " " << endl;
		char ch;
		ifstream reada("char.txt");
		reada >> ch;
		write << ch;
		reada.close();

		// characterArray.txt
	// now for characters arr 
		write << endl;
		char arr[100];
		ifstream reaad("characterArray.txt");
		reaad.getline(arr, 100);
		write << arr;
		reaad.close();

	}
	else {
		cout << " closed " << endl;
	}






	return 0;
}












