#include<iostream>
#include<fstream>
using namespace std;
int main() {
	int x [10];
	ifstream read("ave.txt");
	int n;
	cout << "enter the num "<< endl;
	cin >> n;
	ofstream write("ave.txt");

	

	if (read.is_open()){
		/*for (int i = 0; i < 10; i++) {
			read >> arr[i];
			cout<< arr[i];
		}*/
		cout << "open " << endl;
	}
	else {
		cout << " closed" << endl;
	}

	if (write.is_open()) {


	}
	else {
		cout << " closed" << endl;
	}



	
	return 0;
}