#include <iostream>
using namespace std;
int main() {
	bool isequals = false;
	bool isequal = false;
	char  username[10], password[10];
	char newpassword[10], uewuserid[10];
	cout << " ----**----manu----**---" << endl;
	cout << " this the basic sign up system  enter your username " << endl;
	cin.getline(username, 10);
	cout << " this the basic sign up system  enter your password " << endl;
	cin.getline(password, 10);

	cout << " login " << endl;
	cout << " enter the user Id " << endl;
		cin.getline (uewuserid, 10);
		cout << " enter the password " << endl;
		cin.getline(newpassword, 10);

		for (int i = 0; i < 10; i++) {

			if (username[i]== uewuserid[i]) {
				isequal = true;
				
			}
			if (password[i]== newpassword[i]) {
				isequals = true;
				break;
			}
		}

		if (isequal == true ){
			cout<< " good user name is correct" << endl;
		}
		else {
			cout << " incorrect  " << endl;
		}

		if (isequals == true) {
			cout << " good password  is correct currently your account is logined " << endl;
		}
		else {
			cout << " incorrect  " << endl;
		}


	return 0;
}