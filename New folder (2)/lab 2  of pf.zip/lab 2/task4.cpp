#include<iostream>
using namespace std;
int main() {
	int index = 0;
	bool isequal = false;
	char arr1[50], arr2[50];
	cout << " enter  the arr 1 " << endl;
	cin.getline(arr1, 50);


	for (int i = 0; i < 50; i++) {
		arr2[i] = arr1[i];
	}

	// copied 

	for (int i = 0; i < 50; i++) {
		cout << arr2[i];
		arr2[i] = '\0';
	}



	return 0;
}