#include < iostream>
using namespace std; 
int main() {

	char arr1[100];
	cout << " enter the arr getlne " << endl;
	cin.getline(arr1, 100);
	int vowels = 0;
	int consonent = 0;
	// now for the cheeking the vowels and consonents 
	for (int i = 0; arr1[i]!='\0'; i++) {

		if ( arr1[i]=='a'|| arr1[i] == 'e'|| arr1[i] == 'i'|| arr1[i] == 'o'|| arr1[i] == 'u') {
			vowels++;
		}
		else {
			consonent++;
		}
	}
	cout << "the numbers of vowels  " << vowels <<  endl;
	cout << "this is the   numbers of   " << consonent << endl;














	return 0;
}