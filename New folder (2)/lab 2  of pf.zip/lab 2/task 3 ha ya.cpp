#include<iostream>
using namespace std;
int main() {
	int index = 0;
	char arr1[50], arr2[50], arr3[100];
	cout << " enter  the arr 1 " << endl;
	cin.getline(arr1, 50);
	cout << " enter  the arr 2 " << endl;
	cin.getline(arr2, 50);

	for (int i = 0; arr1[i] != '\0'; i++) {
		arr3[i] = arr1[i];
		index = i;
	}

	for (int j = 0; arr2[j] != '\0'; j++) {
		arr3[j + index + 1] = arr2[j];

	}


	cout << " this the arr connected " << endl;
	for (int j = 0; arr3[j] != '\0'; j++) {

		cout << arr3[j];
		arr3[j] = '\0';
	}

	return 0;
}