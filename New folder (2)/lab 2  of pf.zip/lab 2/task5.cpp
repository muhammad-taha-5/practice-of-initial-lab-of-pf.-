#include <iostream>
using namespace std; 
int main() {
	char arr1[10];
	cout << " enter the arr by user " << endl;
	cin.getline(arr1, 10);
	// now for revercing the arrthe orignal  
	for (int i = 0; i < 10; i++) {
		cout << arr1[i];
    }
	//reverced
	for (int i = 10; i > 0; i--) {
		arr1[i] = arr1[i];
		cout << arr1[i];
	}










	system("pause"); 
	return 0;
}