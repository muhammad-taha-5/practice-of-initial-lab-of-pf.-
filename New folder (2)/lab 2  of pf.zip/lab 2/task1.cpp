#include<iostream>
using namespace std;
int main() {
	int count = 0;

	
	char ch[100];
	cout << "enter this the char arr  input ";
	cin.getline(ch, 100);
	 

	for (int i = 0; ch[i] != '\0'; i++)
	{
		count ++;
	}

	cout << " this total length of arr: " << count << endl;


	
	return 0;
}