#include<iostream>
#include<fstream>
using namespace std;
int main() {
	ifstream read ("doc.txt");
	int arr[20] = {0};
	int a;
	int index = 0;
	while (!read.eof()){
		read >> a;
		cout <<a;
		arr[index++] = a ;
		read.close();
	}

	// for see the arr  
	
	int c1, c2, c3, c4, c5 = 0; 

	for (int i = 0;arr[i]!='/0'; i++) {

		if (arr[i] > 0){

			c1++;
		}else if (arr[i] <  0){
			
			c2++;
		}
		else if (arr[i] %2==0) {
			
			c3++;
		}
		else if (arr[i] % 2 != 0) {
			
			c4++;
		}
		else if (arr[i] == 0) {
			
			c4++;
		}

	}
	cout << " this the positive " <<c1 << endl;
	cout << " this the negative  " << c2 << endl;
	cout << " this the even " << c3 << endl;
	cout << " this the odd " << c4<< endl;
	cout << " this the zero  " << c5 << endl;
	return 0;
}

________________________________________________>>__________________________________ with other way >> 

#include <iostream>
#include <fstream>
using namespace std;
int fun( ){
	int num;
	bool  is_prime = true;
	int counte=0;
	int neg = 0; 
	int counto=0; 
	int prime = 0;
	int notprime = 0;
	int pos = 0;
	ifstream read("tt.txt");
	if (read.is_open() ){
		cout << " open " << endl;
		while (read >> num) {
			if (num > 0) {
				pos++;
			}
			else if (num < 0) {
				neg++;
			}
			else if (num %2==0 ){
				counte++;
			}else if (num % 2 != 0) {
				counto++;
			}else if (num % 2 == 0|| num % 3 == 0|| num % 4 == 0){// not prime
				notprime++;
			}else{  
				prime++;
			}

		}
		cout << " even " << counte << endl;
		cout << " odd " << counto << endl;
		cout << " prime " << prime << endl;
		cout << " not  prime " << notprime << endl;
		cout << " poitive " << pos << endl;
		cout << "negative " << neg << endl;
	}
	else {
		cout << " not opened " << endl;
	}
	return 0;
}





int main() {
	cout << fun();

}
