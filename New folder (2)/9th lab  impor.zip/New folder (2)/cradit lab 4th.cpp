#include<iostream>
using namespace std;


int main() {

	float  arr[2][2]{ 2 , 4
				  ,11, 8 };

	for (int i = 0; i < 2; i++) {

		for (int j = 0; j < 2; j++) {
			cout << arr[i][j] << " ";

		}

		cout << endl;
	}

	cout << " this the matix that is the completly transposed  " << endl;

	for (int j = 0; j < 2; j++) {

		for (int i = 0; i < 2; i++) {
			cout << arr[i][j] << " ";

		}
		cout << endl;
	}

	// static  way of is not allowed 
	   /* int tem1 = 2, temp2= 8, temp3=11,  temp4 =4 ;
		int a = tem1 * temp2;
		int b = temp3 * temp4;
		int c = a - b; */
		// not static  

	int c = arr[0][0] * arr[1][1] - arr[0][1] * arr[1][0];


	// other  ways is  that 
	int d1 = 1;
    int  d2 = 1;
	int k = 1;


	for (int i = 0; i <= 1; i++) {
		d1 *= arr[i][i];
	}

	for (int i = 0; i <= 1; i++) {
		d2 *= arr[i][k];
		k--;
	}


     int c2 = d1 - d2;




	cout << " this the ditermininte " << c << endl;

	float arr2[2][2];
	for (int i = 0; i < 2; i++) {

		for (int j = 0; j < 2; j++) {

			arr2[i][j] = arr[i][j] / c;
		}
	}

	for (int i = 0; i < 2; i++) {

		for (int j = 0; j < 2; j++) {

			cout << arr2[i][j] << " ";


		}
		cout << endl;
	}


	return 0;
}