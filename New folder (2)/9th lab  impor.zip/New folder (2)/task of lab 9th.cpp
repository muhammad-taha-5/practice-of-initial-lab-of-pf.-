     #include<iostream>
	using  namespace std; 
	void fun ( int arr [][3], int  r , int c ) {
		 
		for (int i = 0; i < 2; i++ ) {
			for (int j = 0; j < 3; j++) {
				 
				cout << arr[i][j]<< " ";
			 }
			cout << endl; 
		}
	}
	void char_fun( char ch_arr[][3],int  r, int c) {
	
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 3; j++) {
	
				cout << ch_arr[i][j] << " ";
			}
			cout << endl;
		}
	}
	int main() {
	
	
		int arr[2][3]; 
	
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 3; j++) {
	
				arr[i][j] = rand()%20; 
			}
		}
	
	
	
		// now for the char
		char ch_arr[2][3];
	
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 3; j++) {
	
				ch_arr[i][j] = 'E';
			}
			cout << endl;
		}
	
	
		char_fun( ch_arr, 2, 3);
	
	
	
		fun(arr,2,3);
	  
	
	
		return 0; 
	}