#include <iostream> 
using namespace std;

int main() {
	char fn[5][50] = {'\0'};
	char ln[5][50] = {'\0'};
       /*for (int i = 0; i < 5; i++) {
		cout << " enter the first name :" << i + 1 << endl;
		cin << fn[i];

		cout << " enter the last name :" << i + 1 << endl;
		cin << ln[i];
	}*/
	for (int i = 0;i < 5; i++){
		cout << " enter the first name :" << i + 1 << endl;
		 cin .getline (fn[i] ,50);

		cout << " enter the last name :" << i + 1 << endl;
		cin.getline (ln[i] , 50);
	}


	// now for murrge. 
	char merge  [10][100] = { '\0' };
	 
	for (int i = 0; i < 5; i++ ){
		int k = 0; 

		for ( int j = 0; fn[i][j]!= '\0'; j++ ){
			merge[i][k++] = fn[i][j];
  		}

		// now for  the putting the space in the  arr b/w first name and last name  

		merge[i][k++] = ' ';


		for ( int  j = 0; ln[i][j] != '\0' ;j++ ){
			merge[i][k++] = ln[i][j];
		}
		merge[i][k] = '\0';


	}

	// now for the  seing the arr 
		for (int i = 0; i < 6; i++){

			for (int k = 0;  merge[i][k] !='\0' ;k++ ){

			 cout << merge[i][k];
			}
	 

			cout << endl;
		}



	return 0; 
}