# include<iostream>
using namespace std; 
void fun (char arr[][3] ) {
	for (int i = 0; i < 2; i++){

		for (int j = 0; j < 3; j++ ) {
			cout << " enter the arr[ " << i << "][" << j << "]   :";
			cin >> arr[i][j];
		 }
		
	 }

	for (int i = 0; i < 2; i++) {

		for (int j = 0; j < 3; j++) {
			
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}

	// by replacing it with 'E' 
	for (int i = 0; i < 2; i++) {

		for (int j = 0; j < 3; j++) {

			 arr[i][j] = 'E';
		}
		
	}

	cout << endl;
	  // 2nd task
	//  by the this the replaced matix showed bellow  with 'E' 
	for (int i = 0; i < 2; i++) {

		for (int j = 0; j < 3; j++) {

			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
	// 3rd task  # -> 3
	cout << endl;
   for (int j = 0; j < 3; j++) {

	for (int i = 0; i < 2; i++) {

			cout << arr[i][j] << " ";
    }
		cout << endl;
	}

   // /  4 TH  task  # -> 4
   cout << endl;
   int c1 = 0; 
   for (int j = 0; j < 3; j++) {

	   for (int i = 0; i < 2; i++){
		   if ( arr[i][j]!= 'E') {
			   c1++;
			}
		   
	   }
	   cout << endl;
   }
   cout << c1 << endl;

}
int main() {
	char  arr[2][3];
	  

	fun(arr); 
	return 0; 
}