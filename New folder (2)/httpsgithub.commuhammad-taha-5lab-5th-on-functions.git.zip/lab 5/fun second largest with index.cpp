#include<iostream >
using namespace std;
int sec_largest_index(int arr[], int s ) {
	arr[s];
	int largest = arr[0]; 
	int sec_largest = arr[0];
	int idex = 0;
	int idex_of_sec_lar = 0;
	for (int i = 0; i < 10; i++){

		if (arr[i] >largest){
			sec_largest = largest;
			largest = arr[i];
			 idex_of_sec_lar = i-1;
			 idex = i; 
		}


	}
	cout <<largest << " this the index of largest"<<  idex << endl;
	cout << sec_largest << " this the index of second largest"  <<  idex_of_sec_lar << endl;



	return sec_largest;

}



int main(){
	int arr[10];
	cout << " enter the arr " << endl;
	for (int i = 0; i < 10; i++) {
		cin >> arr[i];
	}

	 cout<< sec_largest_index(arr, 10);





	return 0;

}