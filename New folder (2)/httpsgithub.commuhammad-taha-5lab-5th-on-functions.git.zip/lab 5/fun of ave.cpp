#include < iostream>
using namespace std;
  int  input (int arr [],int size)
  {
	float ave = 0; 
	int sum = 0; 
	for (int i = 0; i < 5; i++) {
		sum += arr[i];
 	}
	ave = sum / size;
	//cout << "Average: " << ave;
	return ave;
}



int main() {
	int  arr[5];
	cout << " enter the arr " << endl;
	for (int i = 0; i < 5; i++) {
		cin >> arr[i];
	}
	cout << "Average: " << input(arr, 5) << endl;

	return 0;
}