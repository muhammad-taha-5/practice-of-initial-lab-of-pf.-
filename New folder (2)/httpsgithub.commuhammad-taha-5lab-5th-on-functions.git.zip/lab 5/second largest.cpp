#include<iostream>
using namespace std;
int sendmax(int arr[], int s) {
	arr[s];
	int largest = arr[0];
	int seclargest = arr[0];

	for (int i = 0; i < 10; i++) {

		if (arr[i] > largest){
			seclargest = largest;
			largest = arr[i];
			

		}
	}
	cout << "largest " << largest << endl;
	// now for the second largest 
	

	cout << "seclargest " << seclargest << endl;
	return seclargest;
}

int main() {

	int arr[10];
	cout << " enter the ARR  to consoul " << endl;
	for (int i = 0; i < 10; i++) {
		cin >> arr[i];
	}
	cout << sendmax(arr, 10);

	return 0;

}