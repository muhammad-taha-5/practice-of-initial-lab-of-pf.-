#include<iostream>
using namespace std;
bool is_prime(int a) {
	int arr[10];

	bool prime = false;

	for (int i = 2; i < 5; i++) {
		if (a % i == 0) {
			prime = 0;

		}
		else {
			prime = 1;
		}
	}




	return prime;

}
int main() {

	int num = 0;
	cout << " enter the the num " << endl;
	cin >> num;



	int result = is_prime(num);
	cout << result; 
	
	if (result == 1) {
		cout << " this is  prime " << endl;
	}
	else {
		cout <<" this the not  prime "  << endl;
	}



	return 0;
}