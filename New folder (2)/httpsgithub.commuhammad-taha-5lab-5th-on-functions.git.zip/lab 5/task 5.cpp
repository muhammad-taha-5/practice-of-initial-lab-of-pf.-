//#include<iostream>
//using namespace std;
//int input_arr(int arr1[], int a, int arr2[], int b) {
//	int index = 0;
//	int arr3[20] = {0};
//	//now for cheeking the data
//	for (int j = 0; j < 10; j++){
//		bool found = false;
//		for (int i = 0; i < 20; i++){
//			if (arr1[i] == arr2[j]){
//				
//				break;
//			}
//			else if (arr1[i] != arr2[j]){
//				arr3[i] = arr1[i];
//
//			}
//
//
//		}
//	}
//	for (int i = 0; i < 20; i++){
//		cout << arr3[i] << " ";
//	}
//	return 0;
//}
//int main() {
//	int arr1[10]{ 1,2,3,4,5,6,7,8,9,10};
//	int arr2[6]{ 1,3,2,10,5,7 };
//
//
//
//
//
//	input_arr(arr1, 10, arr2, 6);
//
//
//	return  0;
//}