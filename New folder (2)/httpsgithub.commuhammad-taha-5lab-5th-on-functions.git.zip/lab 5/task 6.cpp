#include<iostream>
#include<fstream>
using namespace std;
int fun_file (int arr[], int s ) {
	arr[s];

	for (int i = 0; i < 10; i++) {

		for (int j = 0; j < 10; j++){
			if (arr[i] == arr[j]){

				arr[i] = arr[i+1];
				cout << arr[i];
			}
		}
	}
	for (int i = 0; i < 10; i++){
		cout << arr[i];
	}

	return 0;
}



int main() {
	int arr[10];
		ifstream read ("doxs.txt");
		if (read.is_open() ){
			for (int i = 0; i < 12; i++) {
				read >> arr[i];
			}
			/*int num; int idex = 0;
			while (read >> num){
			
				arr[idex++] = num;
			
			}*/
			for (int i = 0; i <12; i++) {
				cout << " arr" << arr[i];
			}
		}
		else {
			cout << " not  opened" << endl;
		}

		fun_file(arr, 10);
		return 0;

}