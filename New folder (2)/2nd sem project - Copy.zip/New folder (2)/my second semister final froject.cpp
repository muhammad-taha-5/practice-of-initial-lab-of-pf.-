#include<iostream >
#include<fstream>
using namespace std;

void sign_up() {
    ofstream read("user.txt");
    char user_name[10];
    int password;


    cout << " enter the user id " << endl;
    cin >> user_name;
    cout << "enter the pass_word  " << endl;
    cin >> password;
    cout << " sign up sussesfully  mubarak ho  " << endl;
    read << user_name << " " << password;

    cout << " now your current  user id is :  "<< user_name << " now your current password is and you are login :"<< password  <<  endl;
}

void markAttendance() {
    const int MS = 100;
    const int ML = 10;
    char rooll_no[MS][ML];
    int total = 0;

    
    ifstream read("file.txt");
    if (read.is_open()) {
        int i = 0, j = 0;
        while (!read.eof()) {
            char ch;
            j = 0;

            while (read.get(ch)) {
                if (ch == ',') break;
                rooll_no[i][j] = ch;
                j++;
                if (j >= ML - 1) break;
            }
            rooll_no[i][j] = '\0'; 

           
            while (read.get(ch) && ch != '\n');
            i++;
            if (i >= MS) break;
        }
        total = i;
        read.close();
    }
    else {
        cout << "not open**" << endl;
        return;
    }


    ofstream att("att.txt", ios::app);
    if (att.is_open()) {
        for (int i = 0; i < total; i++) {
            int present;
            cout << "Is student  reg :";
            for (int k = 0; rooll_no[i][k] != '\0'; k++) {
                cout << rooll_no[i][k];
            }
            cout << " present???   1 = Yes, 0 = No: ";
            cin >> present;

            // Write to  fli.txt
            for (int k = 0; rooll_no[i][k] != '\0'; k++) {
                att << rooll_no[i][k];
            }
            float  date;
            cout << "enter the date" << endl;
            cin >> date;
            att  << "," << date;
            att << "," << present << endl;
        }
        att.close();
        cout << "Attendances marked successfully mubarak ho." << endl;
    }
    else {
        cout << "Error" << endl;
    }
}

void Search_student_Attendance(){
    int roll;
    cout << "Enter roll number: ";
    cin >> roll;
    int absence = 0;
    int r, date, attendance;
    char comma1, comma2;
    int count = 0;

    ifstream read("att.txt");

    if (read.is_open()) {
        cout << "File opened successfully**" << endl;

        while (read >> r >> comma1 >> date >> comma2 >> attendance) {
            if (r == roll && attendance == 1) {
                count++;

            }
            else if (r == roll && attendance == 0) {
                absence++;
            }
        }
        cout << "Total days absence: " << absence << endl;
        cout << "Total days present: " << count << endl;
    }
    else {
        cout << " not  open**" << endl;;
    }
}





                                      // rcurssion 
void Individuals_Report() {
    Search_student_Attendance();
    ifstream read("file.txt"); 
    char arr[100];
    if(read.is_open()) 
    {
        cout << " open " << endl;
        while (read.getline(arr, 100) && !read.eof()) { 
            cout << arr << endl; 
        }
      
    }
    else {
        cout << " not open " << endl;
    }

   



}


void Class_Report() {
    ifstream file("file.txt");

    if (!file.is_open()) {
        cout << "not opened**" << endl;
        return;
    }

    cout << "\n******** Displaying student records from file.txt ********\n";

    char line[100];

    while (file.getline(line, 100)) {
        cout << line << endl;
    }

    file.close();

    ifstream reads("att.txt");

    int roll, date, attendance;
    char comma1, comma2;

    if(reads.is_open()) {
        cout << " open " << endl;;
        cout << ":*********** Student Attendance Records ***********" << endl;

        while (reads >> roll >> comma1 >> date >> comma2 >> attendance) {
            cout << "Roll No: " << roll
                << " | Date: " << date
                << " | Att: " << (attendance == 1 ? "P" : "A") << endl;
        }

        reads.close();
    }
    else {
        cout << "  not opemed **" << endl;
    }
}





void View_Defaulters() {
    int roll, val, date, rolls;
    char ch, ch2;
     // count ting the attendence roll number wise 
    int count_r[100];   
    // counting  prsent roll !
    int count_p[100];
    // store unique roll numbers ;
    int roll_l[100];    
    int uniq_cont = 0;

    
    for (int i = 0; i < 100; i++) {
        count_r[i] = 0;
        count_p[i] = 0;
        roll_l[i] = 0;
    }

    ifstream reads("att.txt");
    if(reads.is_open())
    {
        while (reads >> roll) {
            reads >> ch; 
            reads >> date;
            reads >> ch2;
            reads >> val; // 0 or  1 used 

          
            int index = -1;
            for (int i = 0; i < uniq_cont; i++){
                if (roll_l[i] == roll){
                    index = i;
                    break;
                }
            }
            if (index == -1) {
                roll_l[uniq_cont] = roll;
                count_r[uniq_cont] = 1;
                uniq_cont++;
            }
            else {
                count_r[index]++;
                if (val == 1) {
                    count_p[index]++;
                }
            }
        }

       
        cout << "\n-- Defalters -------------------- these are the who are bellow the (75%) \n";
        for(int i = 0; i < uniq_cont; i++) 
        {
            int total = count_r[i];
            int temp = count_p[i];
            int p = (temp * 100) / total;
            if (p < 75) {
                cout << "Roll no: " << roll_l[i] << " => Attendance: " << p << "%" << endl;
            }
        }

        reads.close();
    }
    else 
    {
        cout << "   not opened " << endl;
    }
}
void  Change_Password(){

        ofstream write ("user.txt",ios::app);
        char user[20];
        int password;   
        cout << "Enter user ID: ";
        cin >> user;
        cout << "Enter changed  password:**" << endl;
        cin >> password;
        if (write.is_open() ){

            write << user << " " << password << endl;
            cout << "User data added successfully **" << endl;
        }
        else {
            cout << " not open  **" << endl;
        }      
 }



//
//void manu() {
//    cout << " **************** after sign in ****************** \n" << endl;
//    
//    cout << "   <-------------- Attendance Menu -----------<< " << endl;
//    cout << "1.<----Mark Daily Attendance_---<< " << endl;
//    cout << "2.<--- View Individuals Report --<< " << endl;
//    cout << "3.<--- View Class Report --<< " << endl;
//    cout << "4.<--- View Defaulters --<< " << endl;
//    cout << "5. <---Search student Attendance --<< " << endl;
//    cout << "6. <---Change Password --<<" << endl;
//    cout << "7. <---Sign Out ---=-- <<" << endl;
//    cout << "Enter choice: --<<" << endl;
//    int aChoice;
//    cin >> aChoice;
//
//    if (aChoice == 1) {
//        markAttendance() ;
//    }
//    else if (aChoice == 2) {
//        Individuals_Report() ;
//    }
//    else if (aChoice == 3) {
//        Class_Report();
//    }
//    else if (aChoice == 4) {
//        View_Defaulters();
//    }
//    else if (aChoice == 5) {
//        Search_student_Attendance();
//    }
//    else if (aChoice == 6) {
//        Change_Password();
//    }
//    else if (aChoice == 7) {
//        cout << "Signing out... successfully" << endl;
//
//
//    }
//    else {
//        cout << "Invalid choice.\n";
//    }
//
//}
// 
// //bool sign_in(){
//    ifstream read("user.txt");
//    char user_name[10];
//    int password;
//    ofstream write("valid_users .txt");
//   
//    cout << " enter the user id " << endl;
//    cin >> user_name;
//    cout << "enter the password  " << endl;
//    cin >> password;
//
//    char fuser_name[10];
//    int fpassword;
//
//
//
//    if (read.is_open()) {
//
//        while (!read.eof()) {
//            read >> fuser_name >> fpassword;
//            for (int i = 0; i < 10; i++) {
//                if (user_name[i] == fuser_name[i]) {
//
//                    if (password == fpassword) {
//                        write << user_name << " " << password;
//                        cout << " welcome back to the ucp portal your id is log in success fully congrates " << endl;
//                        int a;
//                        cout << " do you want to mark the attendence if yes (  '1'  )  else {  '0'  }" << endl;
//                        cin >> a;
//                        if (a == 1) {
//                            cout << " this  is the attendence sheet " << endl;
//                            manu();
//
//                        }
//                        else {
//                            cout << " it means  you don't want to mark the attendence " << endl;
//                        }
//
//                        return true;
//                        //  now here call the function of attendence 
//
//                    }
//                }
//            }
//        }
//        read.close();
//    }
//}


bool sign_in() {
    ifstream read("user.txt");
    char user_name[10];
    int password;
    char fuser_name[10];
    int fpassword;

    cout << " enter the user id " << endl;
    cin >> user_name;
    cout << "enter the password  " << endl;
    cin >> password;

    if (read.is_open()) {
        while (read >> fuser_name >> fpassword) {
            bool matched = true;
            for (int i = 0; i < 10; i++) {
                if (user_name[i] != fuser_name[i]) {
                    matched = false;
                    break;
                }
                if (user_name[i] == '\0' && fuser_name[i] == '\0') break;
            }

            if (matched && password == fpassword) {
                cout << "Login successful. Welcome back!\n";

                // Now show menu in a loop until sign out
                int aChoice;
                do {
                    cout << "\n   <-------------- Attendance Menu ---------**" << endl;
                    cout << "1.<----Mark Daily Attendance_---<<**" << endl;
                    cout << "2.<--- View Individuals Report --<<**" << endl;
                    cout << "3.<--- View Class Report --<<**" << endl;
                    cout << "4.<--- View Defaulters --<<**" << endl;
                    cout << "5. <---Search student Attendance --<<**" << endl;
                    cout << "6. <---Change Password --<<**" << endl;
                    cout << "7. <---Sign Out ---=-- <<**" << endl;
                    cout << "Enter choice: --<< **" << endl;
                    cin >> aChoice;

                    if (aChoice == 1) { markAttendance(); }
                    else if (aChoice == 2) { Individuals_Report(); }
                    else if (aChoice == 3) { Class_Report(); }
                    else if (aChoice == 4) { View_Defaulters(); }
                    else if (aChoice == 5) { Search_student_Attendance(); }
                    else if (aChoice == 6) { Change_Password(); }
                    else if (aChoice == 7) { cout << "Signing out..**" << endl; }
                    else {  cout << "Invalid choice**" << endl ;   }

                } while (aChoice != 7);

                return true;
            }
        }
        read.close();
    }

    cout << "Login failed. Please check your ID or password**" << endl;
    return false;
}




void changePassword(int index, char arr2[10]) {
    ifstream read("user.txt");
    ofstream re("user.txt", ios::app);
    char arr[10];

    while (!read.eof()) {
        read >> arr;
        for (int i = 0; i < 10; i++) {
            if (arr[i] == arr2[i]) {

                int  newpass = 0;
                cout << "Enter new password: " << endl;
                cin >> newpass;

                re << arr << " " << newpass << endl;

                cout << "Password changed**" << endl;

            }
        }
    }
}



int main()
{
    int choice;
    int sIndex = -1;

    do {
        cout << "--- Attendance Recorder System ---" << endl;
        cout << "1 Sign Up  " << endl ;
        cout << "2 Sign In " << endl;
        cout << "3 Change Password" << endl;
        cout << "4 Sign Out" << endl;
        cout << "5 Exit" << endl;
        cout << "Enter choice: " << endl;
        cin >> choice;
        if (choice == 1){
            sign_up();
        }
        else if (choice == 2){ 
            sIndex = sign_in();
        }
        else if (choice == 3) {
            char arr[10];
            cout << " enter the user id "<< endl;
            for (int i = 0; i < 6; i++) {
                cin >> arr[i];
            }
            if (sIndex != -1)

                changePassword(sIndex, arr);
            else
                cout << "Please sign in first.\n";

        }
        else if (choice == 4)
        {
            if (sIndex != -1) {
                sIndex = -1;
                cout << "Signed out successfully.\n";
            }
            else {
                cout << "Not signed in.\n";
            }
        }
        else if (choice == 5)
        {
            cout << "Exiting...\n";
            break;
        }
        else {
            cout << "Invalid option.\n";
        }
    } while (choice != 5);

    return 0;
}