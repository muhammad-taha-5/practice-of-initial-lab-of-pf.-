#include<iostream>
#include <fstream>
using namespace std; 

int fun( int arr [], int s ) {
	arr[s];
	// now for pointers 
	int* p1 = arr;// *p1 = &arr[0]
	for (int i = 0; i << 10; i++) {
		p1 = &arr[i];// now all index  of arr is stored in the pointer one by one  as loop runs 

	}
	cout << " this the index of arr "<< p1 << endl;          //arr[i] showed byconsole 
	cout << " these are the  numbers in the present in p1   " << *p1 << endl;
	for (int i = 0; i < 10;i++){
		// now for seeing the arr the arr arr numbers derefrecing the pointers   
		cout << *(p1 + i);
	}



	return 0; 
}
int main(){
	ifstream read ("dox.txt");
	int num[10];
	int i = 0;
	// if for num //  read >> num but inside while    
	while (!read.eof ()){
		read >> num[i];
		cout << num[i];
		i++;
	}
	/*for (int i = 0;i< 10; i++) {
		read >>num[i];
		cout<< num[i];
	}*/





	fun( num , 10 );
	return 0;
}