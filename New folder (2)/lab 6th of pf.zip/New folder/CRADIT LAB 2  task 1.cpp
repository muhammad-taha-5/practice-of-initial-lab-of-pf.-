//#include<iostream>
//using namespace std; 
//char ch (string s){
//
//	cout << s; 
//	int count = 0; 
//	char ch;
//		cout << " enter the char search for " << endl;
//		cin >> ch;
//	for (int i = 0; i < 100; i++){
//		if ( s[i]==ch ){
//			count++;
//
//		}
//
//	}
//	cout << "this count number " << count << endl;
//
//
//	return ch ;
//}
//
//int main(){
//
//	string s;
//		cout << " enter the string  " << endl;
//	cin >> s;
//
//
//
//
//	 cout<< ch(s);
//
//
//	return 0; 
//
//}