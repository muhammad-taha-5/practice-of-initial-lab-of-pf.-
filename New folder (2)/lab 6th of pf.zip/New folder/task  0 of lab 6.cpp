#include<iostream>

using namespace std; 
int main() {
	int n1=10;
	int n2= 20;
	int* p1;
	int* p2;
	p1 = &n1;
	cout << "num 1   addres " << p1 << endl;
	p2 = &n2;
	cout << "num 1   addres " << p2 << endl;
	// by using derefrence.
	cout << "addition  " << *p1 + *p2 << endl;

	cout << "subtraction " << *p1 - *p2 << endl;

	cout << "multiplecation " << *p1 * *p2 << endl;

	cout << "divide " << *p1 / *p2 << endl;
	cout << "divide " << *p1 / *p2 << endl;



	return 0;
}