#include<iostream>
using namespace std;
int main() {

	int n1 = 10;
    int n2 = 20;
	int* p1 = &n1;
	int* p2 = &n2;
	
	// swaping of values  
	int  temp = *p1;
	p1 = p2;
	p2 = &temp;
	// swaped sucessfully     // viweing them by deferencing  
	cout << " let me see swaped num " << *p1 << "," << *p2 << endl;
















	return 0;
}
