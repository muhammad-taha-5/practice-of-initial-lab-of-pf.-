#include<iostream>
#include<fstream>
using namespace std;
int main() {
	int c1 = 0;
	
	char arr[100];
	int* p1;
	ifstream read("dox.txt");
	ofstream write("taha.txt");

	if (read.is_open()) {
		int i = 0;
		 // taking one by one word into arr 
		while (read >> arr){

			int c1 = 0;
			for (int i = 0; arr[i]!='\0'; i++){
				c1++;
			}
			p1 = &c1;
			cout << "this printed by cosoule ";
			cout << c1 << " ";
			cout << endl;
			cout << "this printed by pointer ";
			cout << "word :" << arr << "   its count  :" << *p1 << " ";
			if (write.is_open () ){
				cout << "open " << endl;
				write << "this printed by pointer  word :  " << arr << "   its count  :" << *p1 << " ";
			}
			else {
				cout << " not open " << endl;
			}
		}
	}
 
	return  0;
}