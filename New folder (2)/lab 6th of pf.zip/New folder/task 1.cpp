#include<iostream>
using namespace std;
int main()
{
	// *ptr // nu8mber in the pointer 
	// &ptr // address  in the pointer.
	// integer  4 bytes 
	//int pointer  4 bytes

	int x, y;
	int* ptr;
	x = 50;
	y = 65;
	ptr = &x;
	cout << x << " " << &x << " " << y << " " << &y << " " << ptr << " " << *ptr << " "
		<< &ptr << endl;
	*ptr = y;
	cout << x << " " << &x << " " << y << " " << &y << " " << ptr << " " << *ptr << " "
		<< &ptr << endl;
	ptr = &y;
	cout << x << " " << &x << " " << y << " " << &y << " " << ptr << " " << *ptr << " "
		<< &ptr << endl;
	return 0;
}