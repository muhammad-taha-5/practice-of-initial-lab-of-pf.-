#include<iostream>

using namespace std;
int main() {
	int n1 = 10;
	int n2 = 20;
	int* p1;
	int* p2;
	p1 = &n1;
	cout << "num 1   addres " << p1 << endl;
	p2 = &n2;
	cout << "num 1   addres " << p2 << endl;
	// by using derefrence.
	int num;
	cout << "enter the  choice " << endl;
	cin >> num; 
	if (num==1){
		cout << "addition  " << *p1 + *p2 << endl;
	}
	else if (num == 2) {
		cout << "subtraction " << *p1 - *p2 << endl;
	}
	else if (num == 3) {
		cout << "multiplecation " << *p1 * *p2 << endl;
	}
	else if (num == 3) {
		cout << "divide " << *p1 / *p2 << endl;
	}
	else {
		cout << " invalid  choice " << endl;
	}
	
	



	return 0;
}