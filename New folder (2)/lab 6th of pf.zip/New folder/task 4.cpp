#include<iostream>
using namespace std; 
int main() {
	int n1 = 19;
	int n2 = 20;
	int n3 = 300;

	int* p1 = &n1;
	int* p2 = &n2;
	int* p3 = &n3;

	int  gerater = INT_MAX;
	if (*p1 > gerater){
		gerater = *p1;
	}
	 if ( *p2 > *p1){
		gerater = *p2;
	}
	 if (*p3 > *p2) {
		gerater = *p3;
	}
	else {
		 cout << gerater << endl;
	}
	cout << " this the greater all  " << gerater << endl;

	return gerater ;
}