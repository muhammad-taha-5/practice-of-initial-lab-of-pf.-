#include<iostream>
#include<fstream>
using namespace std;

int  fun() {

	int sum = 0;
	int num;
	ifstream read("dox.txt");

	while (!read.eof()){

		if (read >> num) {

			sum += num;
		}
			
	}



	return sum;
}

int main() {


	cout << " origanal num : " << 2334 << " sum " << fun();








	return 0;
}