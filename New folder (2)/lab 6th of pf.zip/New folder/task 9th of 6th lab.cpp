#include<iostream>
#include<fstream>
using namespace std;
int main() {
	int c1 = 0;
	
	char arr[100];
	int* p1;
	ifstream read("dox.txt");
	ofstream write("taha.txt");

 
	while (read >> arr) {
		bool ispalandrome = false;
		int i = 5;

		char rev[10]; // now put arr in the rvesesed form 

		for (int j = 0; j < 10; j++) {
			rev[i] = arr[j];
		}
		int j = 0;
		for (int i = 0; arr[i] != '\0'; i++) {
			if (rev[i] == arr[j]) {
				cout << rev[i];
				ispalandrome = true;
			}

			j++;

			//cout << arr<<endl;
		

		}
			if (ispalandrome == true){
				cout << arr << "this is the palandrome " << endl;
				write<< arr << "this is the palandrome " << endl;
			}
			else {
				cout << arr << "this is  the palandrome " << endl;
				write << arr << "this is the palandrome " << endl;
			}

	}



	return  0;
}