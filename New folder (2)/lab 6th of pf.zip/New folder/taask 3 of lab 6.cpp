#include<iostream>
using namespace std; 

int main(){
	int n1;
	cout << "enter the  n1 " << endl;
	cin >> n1; 

	int n2;
	cout << "enter the  n2 " << endl;
	cin >> n2;

	int* p1 = &n1;
	int* p2 = &n2; 
	
	char ch ; 
	cout << "enter the char oprater for the doing operation " << endl;
	cin >> ch;
	//derefrace the pointer for gatting  values of num1  and num2  

	// this can only  compeared.   
	char* cptr = &ch;


	if (*cptr == '+')
	{
		cout << "Sum" << *p1 + *p2 << endl;
	}
	else if (*cptr == '-')
	{
		cout << "subtraction " << *p1 - *p2 << endl;
	}
	else if (*cptr == '*')
	{
		cout << "multiply  " << *p1 * *p2 << endl;
	}
	else if (*cptr == '/'){
		cout << "divide  " << *p1 / *p2 << endl;
	}
	else {
		cout << " invalid " << endl;
	}
	




	return 0; 
}