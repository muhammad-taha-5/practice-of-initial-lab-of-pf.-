#include<iostream>
#include<fstream>
using namespace std;
int  fun(ifstream &fun){
	int arr[10];
	int i = 0; 
	while (!fun.eof()) {
		fun >> arr[i];
		i++;
	}
	cout << "this the arr takes  nums form file " << endl;
	for (int i = 0; i < 10; i++) {
		cout << arr[i];
	}

	int seclargest = 0;
	int largest = arr[0];
	int smallest = arr[0];
	int sec_small = 0;
	for (int i = 0; i < 10; i++){
		if (arr[i] < smallest) {
			sec_small = smallest;
			smallest = arr[i];

		}

		if (arr[i] >largest){
			seclargest = largest;
				largest = arr[i];
		}
	}


	cout << " these are the  both digits"<< sec_small<< seclargest <<endl;
	

		return 0; 
}
int main(){
	ifstream read("dox.txt");



	fun(read);
	return 0;
}