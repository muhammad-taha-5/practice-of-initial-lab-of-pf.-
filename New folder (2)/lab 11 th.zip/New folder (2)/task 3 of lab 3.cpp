#include<iostream>
using namespace std;
int main () {
	//int s = 3;
	//int* arr = new  int[s];
	//int s2 = 3;
 // int* arr2 = new  int[s2];
 // int s3 = 3; 
 // int* multi = new int[s3];
	//   multi[0] = 1;
	//   multi[1] = 1;
	//   multi[2] = 1;
	//  // now for the  cin 
 //    cout << "enter the 1st arr2 " << endl;
	//  for (int i = 0; i < s; i++) {
	//	  cin >> arr[i];

	//  }
	//  cout << "enter the 2nd arr2 " << endl;
	//  for (int i = 0; i < s2; i++) {
	//	  cin >> arr2[i];

	//  }


	  //    if (s==s2) { 
			//  for (int i = 0; i < 3; i++) {
			//	  multi[i] = arr[i] * arr2[i];
			//  }
	  //    }


		/*for (int j = 0; j < 3; j++) {

			cout << " this the multpli arr :" << multi[j]<< " " <<endl ;

		}*/


	                   // 2nd task 

		

		/*if (s == s2){
			for (int j = 0; j < 3; j++) {

				for (int i = 0; i < 3; i++) {
					multi[j] += arr[i] * arr2[j];
				}

			}
		}
		  
		for (int j = 0; j < 3; j++) {

			cout << " this the multpli arr :" << multi[j] << " " << endl;

		}*/



		                      // 3nd task  cin 2d arr dynamically 
	      
	int  r, c ;
	r = 4; 
	c = 5;

	int** arr = new int* [r];
	for (int i = 0; i < r; i++) {
		arr[i] = new  int[c];
	}


	int  r2, c2;
	r2 = 5;
	c2 = 4;
	int** arr2 = new int* [r2];
	for (int i = 0; i < r2; i++) {
		arr2[i] = new  int[c2];
	}
	int index = 1;
	
	  
	for (int i = 0; i < r; i++) {
		for (int j = 0; j < c ; j++) {
			cout << " enter the values " << index++ << endl;
			cin >> arr[i][j];
		 }
	 }
	cout << " enter the 2nd arr " << endl;
	index = 1;
	for (int i = 0; i < r2; i++) {
		for (int j = 0; j < c2; j++) {
			cout << " enter the values " << index++ << endl;
			cin >> arr2[i][j];
		}
	}
	// now making the 3rd arr multi

	int  mr = 4, mc = 4;
	int** multi = new  int* [mr];
	for (int i = 0; i < mr; i++){
		multi[i] = new int[mc];
    }

	if (r == c2){
		for (int i = 0; i < mr; i++) {
			for (int j = 0; j < mc; j++) {
				multi[i][j] = arr[i][j]* arr2[i][j];
			}
		}
	}

	for (int i = 0; i < mr; i++) {
		for (int j = 0; j < mc; j++) {
			  cout<<"   "<< multi[i][j] ;
		}
		cout << endl;
	}



	return 0; 
}