//#include<iostream>
//#include<fstream>
//
//using namespace std; 
//int  main() {
// 
//	int  s = 6; 
//	int* arr = new int [s]; 
//	ifstream read("valid_users .txt");
//	int i = 0; 
//	while(!read.eof()){
//		read >> arr[i];
//		i++; 
//	}
//	for (int i = 0; i < s; i++) {
//		 cout<< arr[i]<< " " ; 
//	}
//	int c, c2, c3;
//	c = 0;
//	c2 = 0;
//	c3 = 0;
//
//	int a, b, cx;
//	for (int i = 0; i < s; i++) {
//		if (arr[0] == arr[i]){
//			a = arr[i];
//			c++;
//		  
//		}else if (arr[1]==arr[i]) {
//			b = arr[i];
//			c2++;
//		}
//		else if (arr[3]==arr[i]) {
//			cx = arr[i];
//			c3++;
//		}
//		 
//
//	}
//
//	cout << " this the 1st " << a << " " << c << endl;
//	cout << " this the 2nd  " << b<<" " << c2 << endl;
//	cout << " this the 3rd "  << cx << " " << c3 << endl;
//
//
//
//
//
//
//
//
//
//
//	return 0; 
// }
                                                                                               // both the tasks are corect                  
#include <iostream>
#include <fstream>
using namespace std;

int main() {
    const int s = 100;
    int* arr = new int[s];
    int count = 0;

    ifstream read("valid_users .txt"); // removed space from filename
    if (!read.is_open()) {
        cout << "Error: Could not open the file.\n";
        return 1;
    }

    // Read from file
    while (count < s && read >> arr[count]) {
        count++;
    }

    // Display the array
    for (int i = 0; i < count; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    // Count occurrences
    int maxCount = 0;
    int mostFreq;

    for (int i = 0; i < count; i++) {
        int current = arr[i];
        int freq = 0;
        for (int j = 0; j < count; j++) {
            if (arr[j] == current) {
                freq++;
            }
        }

        if (freq > maxCount) {
            maxCount = freq;
            mostFreq = current;
        }
    }

    cout << "Most frequent number = " << mostFreq << " (appeared " << maxCount << " times)" << endl;

    delete[] arr;
    return 0;
}
