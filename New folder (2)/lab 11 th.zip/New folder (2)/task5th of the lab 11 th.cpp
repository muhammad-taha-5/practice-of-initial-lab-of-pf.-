#include<iostream>
#include <fstream>
using namespace std; 
int main(){ 
	ifstream read("valid_users .txt");
	if (read.is_open()) {
		cout << " open " << endl;
		/*int s = 5;
		int i = 0;
		int* arr = new  int[s];

		while (!read.eof()) {
			read >> arr[i];
			i++;
		}
		int count = 0;
		for (int i = 0; i < s; i++) {
			bool is_prime = true;
			for (int j = 2; j <= arr[i] / 2; j++) {
				if (arr[i] % j == 0){
					is_prime = false;
					break;
				}
			}
			if (is_prime) {
				count++;
				cout << arr[i] << " is prime.\n";
			}
		}
		cout << " count:"<< count << endl;
	      }
	     else {
	     	cout << " not open " << endl;
			}
      	*/

	//  same task with  2d array    
		int r, c;
		r = 5;
		c = 4;
		int count2 = 0;

		int** arr2 = new int* [r];
		for (int i = 0; i < r; i++) {
			arr2[i] = new int[c];
		}

		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				arr2[i][j] = rand() % 20;
			}
		}

		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				cout << arr2[i][j]<< "  " ;
			}
		}
		cout << endl;

		  // now for the conuting the prime numbers    
		for (int i = 0; i < r; i++  ) {
			for (int j = 0; j < c; j++) {
				int  num = arr2[i][j];
				bool isprime = true;
				if ( num < 1){
					 
				}
				else {
					for (int k = 2; k < num / 2;k++ ) {
						if (num% k == 0) {
							isprime = false; 
							break; 
						}
						else if (isprime){
							cout << " is prime "<< num <<  endl;
							count2++; 
						}
					}

				}
			 }
		}

		cout << " these sre the prime numbers : " << count2;
	}
	else {
		cout << " not open " << endl;
	}


	return 0; 
}
