#include<iostream>
#include <fstream>
using namespace std;
int main() {
	ifstream read("valid_users .txt");

	/*int i = 0;
	int s = 7;
	int* arr = new  int [s];
	while ( i< s  ){
		read >> arr[i];
		i++;
	}
	for (int j = 0; j < s; j++) {
		cout << "  " << arr[j];
	}

	int c = 0;
	cout << endl;

	for (int j = 0; j < s; j++) {
		if (arr[j] < 0) {
			arr[j] = 0;
			c++;
		}


		cout  << "  " << arr[j];
	}
	cout << endl;

	cout << " how many are less than zero " << c <<endl ;
	*/

	// same rask 2d  arr

	int r, c;
	cout << " enter the  rows and col " << endl;
	cin >> r >> c;
	int i = 0; 

	int** arr = new int* [r];
	for (int i = 0; i < c; i++) {
		arr[i] = new int [c];
	} 
	 
	if (read.is_open()) {
		cout << "open " << endl;
		while (!read.eof()){
			for (int i = 0; i < c; i++) {
				 
				for (int j = 0;j < c; j++) {
					read >> arr[i][j];
				}
			}
		}

	}
	else
	{
		cout << " not open " << endl;
	}
	cout << " before changing " << endl;
	for (int i = 0; i < c; i++) {
		for (int j = 0; j < c; j++) {
			cout<< " "<<  arr[i][j];
		}
		cout << endl; 
	}

	for (int i = 0; i < c; i++) {
		for (int j = 0; j < c; j++) {
			if ( arr[i][j]<0) {
				arr[i][j] = 0;
		    }
		}
		cout << endl;
	}
	cout << " after  changing " << endl;
	for (int i = 0; i < c; i++) {
		for (int j = 0; j < c; j++) {
			cout << " " << arr[i][j];
		}
		cout << endl;
	}





							 
	return 0;
}
