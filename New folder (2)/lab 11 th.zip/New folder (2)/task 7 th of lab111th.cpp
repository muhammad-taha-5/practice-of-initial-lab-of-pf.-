#include<iostream>
#include<fstream>
using namespace std; 
int main() {
	ifstream read ("valid_users .txt");
	/*int  s = 5;
	int i = 0;
	int* arr = new int [s];
	if (read.is_open()){
		cout << " open " << endl;
		while (i < s) {
			read >> arr[i];
			i++;
		}

		for (int i = 0; i < s; i++) {
			cout << arr[i] << endl;
		}
		int* p1 = &arr[s-1];
		cout << "  this the addess of these  values  "<<endl;
		for (int i = 0; i < s; i++) {
			cout << p1 - i << endl; 
		 }
		cout << "  this the valus of these  values  " << endl;
		for (int i = s-1 ; i >=0 ;i--) {
			cout << *p1 - i<< endl;

		}
	}*/

	// now the same thing for the 2d arr with same task 
	if (read.is_open()) {
		int r, c; 
		r = 5;
		c = 4;
		
		int** arr = new int* [r];
		for (int i = 0; i < r; i++ ) {
			arr[i] = new int[c];
		}
		int* p2=  &arr[r-1][c-1];
		cout << " open  " << endl;
		while (!read.eof()) {
			for (int i = 0; i < r; i++) {
				for (int j = 0; j < c; j++){
					read >> arr[i][j];
				}
			}
		  }
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				cout<<arr[i][j]<< " ";
			}
			cout << endl;
		}

		 // reversed 
		cout << " reversed" << endl;
		for (int i = r-1; i  >=0; i--) {
			for (int j =c-1; j >=0 ; j--){
				
				cout << *p2 + i + j << " ";

			}
			cout << endl;
		}



		
	}








	return 0;
 }