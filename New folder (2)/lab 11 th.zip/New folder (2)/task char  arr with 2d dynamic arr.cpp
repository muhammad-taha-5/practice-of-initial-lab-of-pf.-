#include<iostream>
//#include<fstream>
using namespace std;
int main() {
	/*ofstream write("valid_users.txt");
	int c, r, i, j;
	cout << " enter the row and col size both : " << endl;
	cin >> r >> c;

	char** arr = new char* [r];
	for (i = 0; i < r; i++ ) {
		arr[i] = new  char[c];
	}

	cout << " enter the name " << endl;
	for (i = 0; i < r; i++) {
		cin.getline(arr[i], c);
	}

	for (i = 0; i < r; i++) {
		cout << arr[i];
		write << arr[i];
	}*/
	// task1  start from here on the 2d dynamic arr 

  ////int n;
  ////cout << " enter the  elements in the  arr " << endl;
  ////cin >> n; 
  //////  the is the  1d  dynamic arr intigers 
////    int * arr = new int[n];
   //// int sum = 0;  
   //// for (int i = 0; i < n; i++) {
   //// cout << " entre the values " << i+1 <<endl;
   ////	 cin >> arr[i];
   ////	 sum += arr[i];
   //// }
   //// float  ave = sum / n;
   //// cout << " this the ave :" << ave <<  endl; 



	// my own task  with  2d arr same 
	int r2, c2;
	cout << " entre the  rows and col :" << endl;
	cin >> r2 >> c2;

	//int arr22[4][3];
	// ths the intially syntx of the

	int** arr2 = new  int* [r2];
	for (int i = 0; i <r2; i++) {
		arr2[i] = new  int [c2];
	}
	// now  for the cin
	int  s =0 ;
	int index = 0;
	for (int i = 0; i < r2; i++ ) {
		for (int j = 0; j < c2; j++  ) {
			cout << "enter the name :" << index++  << endl ;
			cin >> arr2[i][j];
			s += arr2[i][j];
		}
	}
	float  ave2 = s / r2 * c2;
	cout << " this the ave2 of the 2d array   :" << ave2 << endl;



	return 0 ; 
}