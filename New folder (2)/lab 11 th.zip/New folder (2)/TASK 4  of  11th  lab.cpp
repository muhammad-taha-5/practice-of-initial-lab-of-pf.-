#include <iostream>
using namespace std; 
int main(){

	int r, c;
	cout << " enter the rows and col" << endl;
	 cin >> r >> c;
	// // 1d dynamic decleration 
	//int* arr = new  int[r] ;
	// // cin   in the 1d  
	//for (int i = 0; i < r; i++ ) {
	//	cin >> arr[i]; 
	//}
	// 
	//int larg = INT_MIN;
	//int sec_larg = 0;

	//for (int i = 0; i < r; i++) {
	//	if (arr[i] > larg){
	//		sec_larg = larg;
	//		larg = arr[i];

	//	}
	//}
	//cout << " this the  second largest " << sec_larg << endl;

 //                           // tASK 2  with 2d arr 

	int larg = INT_MIN;
	int sec_larg = 0;

	
	//  same for the 2d arr 
	 // 1d dynamic decleration 
	int** arr2 = new  int* [r];
	for (int i = 0; i < r; i++) {
		arr2 [i] = new int [c];
	}
	int index = 0; 
	for (int i = 0; i < r; i++){
		for (int j = 0; j < c; j++){
			cout << " enter the value" << index++ << endl;
			cin >> arr2[i][j];
		}
	}
	for (int i = 0; i < r; i++) {
		for (int j = 0; j < c; j++ ){
			if (arr2[i][j] > larg) {
				sec_larg = larg;
				larg = arr2[i][j];

			}
		 }
	}
	cout << " this the  second largest " << sec_larg << endl;







	return 0;
}