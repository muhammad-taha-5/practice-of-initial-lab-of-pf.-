#include<iostream>
using namespace std;
int main() {
    // 	int s;
    // 	cout << " enter the size "<<endl;
    // 	cin >> s; 

    // 	int* arr = new int [s];

    // 	for (int i = 0; i < s; i++){
    // 		cout << "enter the arr "<< i+1 << endl;
    // 		 cin >> arr[i];
    // 	}

    // 	for (int i = 0; i < s; i++){
    // 		if (arr[i] % 2 == 0) {
    // 			cout << "even " << arr[i] << "\t";
    // 		}
    // 		else {
    // 			cout << "odd " << arr[i] <<"\t";
    // 		}
    // 	}


        // now with 2d arr
    int  r, c;
    cout << " enter the size " << endl;
    cin >> r >> c;

    // now for allocating the memory 2d array 

    int** arr2 = new int* [r];
    for (int i = 0; i < r; i++) {
        arr2[i] = new  int[c];

    }
    //    now for the cin  
    int index = 0;
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            cout << " enter the num arr " << index++ << endl;
            cin >> arr2[i][j];

        }
    }


    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            if (arr2[i][j] % 2 == 0) {
                cout << "even " << arr2[i][j] << "\t";
            }
            else {
                cout << "odd " << arr2[i][j] << "\t";
            }

        }
    }




    return 0;
}