#include<iostream>
#include<fstream>
using namespace std; 
int main() {

	/*int i ,j ; 
	int const  r = 5 ;
	int  c;
	cout << " enter the col  "<< endl;
	cin >> c ; 


	int** arr = new  int* [r];
	for ( i=0; i< r ; i++){
		arr[i] = new int[c]; 
	}


	for (i = 0; i < r;  i++) {
		for (j = 0; j < c; j++){
			arr[i][j] = rand() % 100;
		}
	}
	for (i = 0; i < r; i++) {
		for (j = 0; j < c; j++) {
			cout << arr[i][j]<< " ";
		}
		cout << endl;
	}*/



	//  2nd  task 2
	/*int r, c; 
	int i, j; 
	cout << "  enter the row" << endl; 
	cin >> r;
	cout << "  enter the  colums  " << endl;
	cin >> c;
	ifstream  read ("doxs.txt");  
	
	int** arr = new  int* [r];
	for (i = 0; i < r; i++) {
		arr[i] = new  int[c];
	}
	while (!read.eof()) {
		for (i = 0; i < r; i++) {
			for (j = 0; j < c; j++) {
			  read >> arr[i][j];
			}
			cout << endl;
		}
	}

	int l = 0; 
	for (i = 0; i < r; i++) {
		for (j = 0; j < c; j++) {
			cout << arr[i][j];
			if (arr[i][j] > l){
				l = arr[i][j];
			}
		}
		cout << endl;
	}
	cout << " largest : " << l <<  endl;*/



                                       //    task # 3
									   



	//int r, c;
	//int i, j;
	//cout << "  enter the row" << endl;
	//cin >> r;
	//cout << "  enter the  colums  " << endl;
	//cin >> c;
	//ifstream  read("doxs.txt");

	//int** arr = new  int* [r];
	//for (i = 0; i < r; i++) {
	//	arr[i] = new  int[c];
	//}
	//while (!read.eof()) {
	//	for (i = 0; i < r; i++) {
	//		for (j = 0; j < c; j++) {
	//			read >> arr[i][j];
	//		}
	//		cout << endl;
	//	}
	//}


	//for (i = 0; i < r; i++) {
	//	for (j = 0; j < c; j++) {
	//		cout << arr[i][j];
	//		
	//	}
	//	cout << endl;
	//}
	//cout << " after " << endl;
	//	for (j = 0; j < c; j++) {
	//for (i = r-1; i >=0; i--) {
	//		cout << arr[i][j];

	//	}
	//	cout << endl;
	//}


                            //tsak  4th

//int r, c;
//int i, j;
//cout << "  enter the row" << endl;
//cin >> r;
//cout << "  enter the  colums  " << endl;
//cin >> c;
//ifstream  read("doxs.txt");
//
//int** arr = new  int* [r];
//for (i = 0; i < r; i++) {
//	arr[i] = new  int[c];
//}
//while (!read.eof()) {
//	for (i = 0; i < r; i++) {
//		for (j = 0; j < c; j++) {
//			read >> arr[i][j];
//		}
//		cout << endl;
//	}
//}
//int n;
//cout << " enter the num/ value " << endl;
//cin >> n; 
//for (i = 0; i < r; i++) {
//	for (j = 0; j < c; j++) {
//		
//		if (arr[i][j] == n){
//			cout << arr[i][j];
//			cout << "  its index "<< i << " " << j << endl ;
//		 }
//
//	}
//	cout << endl;
//}



int  const r =3; 
int i = 0, j = 0; 

int col[r] ;
for (i = 0; i < r; i++ ) {
	cout << " enter the col of each row " << i<< endl;
	cin >> col[i];
}
 
// now for making the dynamic memory location  2d jeckrd arr 
  int** arr = new int*[r];
  for (i = 0; i < r; i++) {
	arr[i] = new  int [col[i]];
   }

ifstream  read("doxs.txt");
if ( read.is_open() ) {
	cout << "open " << endl;

	while (!read.eof()) {
		for (i = 0; i < r; i++) {
			for (j = 0; j < col[i]; j++) {
				read >> arr[i][j];
			}
		}
	}

	for (i = 0; i < r; i++) {
		for (j = 0; j < col[i]; j++) {
			cout << arr[i][j]<< "  "  ;
		}
		cout << endl ;
	}

}






	return 0; 
}