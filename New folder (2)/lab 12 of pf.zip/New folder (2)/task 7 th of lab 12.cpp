#include<iostream> 
#include<fstream>
using namespace std;
int main() {
	ifstream reads("f.txt");
	ifstream read("l.txt");
	int  r, c;
	reads >> r;
	c = 7;
	
	reads.ignore();

	char** arr = new  char* [r];
	for (int i = 0; i < r; i++){
		arr[i] = new  char [c];
	}
     
	if (reads.is_open() ){
		cout << "  opened " << endl;
		 
		while (!reads.eof()) {
			for (int i = 0; i < r; i++){
			 reads.getline (arr[i],15);
				
			}

		}
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c;j++ ){
				 cout<< arr[i][j];
			}
			cout<<endl;
		}

		// now for 2nd file   2nd names 
		int  r2, c2;
		read >> r2;
		c2 = 7;
		read.ignore();

		char** arr2 = new  char * [r2];
		for (int i = 0; i < r2; i++) {
			arr2[i] = new  char[c2];
		}

		while (!read.eof()) {
			for (int i = 0; i < r2; i++) {
				read.getline(arr2[i], 10);
			}
		}


		for (int i = 0; i < r2; i++) {
			for (int j = 0; j < c2; j++) {
				cout << arr2[i][j];
			}
			cout << endl;
		}

		int r3 = 4;
		int c3 = 20;

		// now for the murge arr 
		char** murge = new  char* [r3];
		for (int i = 0; i < r3; i++) {
			murge[i] = new  char[c3];
		}

		int index = 0;
		for (int i = 0; i < r3; i++ ) {
			for (int j = 0; j < c3; j++) {
				murge[i][j] = arr[i][j];
				index = j;
			}
		 }


		for (int i = 0; i < r3; i++) {
			for (int j = 0; j < c3; j++) {
				murge[i][j + index] = arr2[i][j];
				
			}
		}

		for (int i = 0; i < r3; i++) {
			for (int j = 0; j < c3; j++) {
				cout << murge[i][j];
			}
		}




	}
	else {

	}





	int  r2, c2;
	read >> r2;
	c2 = 15;
	char** arr2 = new  char* [r2];
	for (int i = 0; i < r2; i++) {
		arr[i] = new  char[c2];
	}







//
//
//#include <iostream>
//#include <fstream>
//	using namespace std;
//
//	int main() {
//		ifstream reads("f.txt");  // first names
//		ifstream read("l.txt");   // last names
//
//		int r, c = 15;
//		reads >> r;
//		reads.ignore();
//
//		char** arr1 = new char* [r];
//		for (int i = 0; i < r; i++) {
//			arr1[i] = new char[c];
//			reads.getline(arr1[i], c);
//		}
//
//		int r2, c2 = 15;
//		read >> r2;
//		read.ignore();
//
//		char** arr2 = new char* [r2];
//		for (int i = 0; i < r2; i++) {
//			arr2[i] = new char[c2];
//			read.getline(arr2[i], c2);
//		}
//
//		// Merging first and last names manually
//		int c3 = 30;
//		char** merged = new char* [r];
//		for (int i = 0; i < r; i++) {
//			merged[i] = new char[c3];
//
//			// Manual copy of first name
//			int j = 0;
//			while (arr1[i][j] != '\0') {
//				merged[i][j] = arr1[i][j];
//				j++;
//			}
//
//			// Add space
//			merged[i][j] = ' ';
//			j++;
//
//			// Manual copy of last name
//			int k = 0;
//			while (arr2[i][k] != '\0') {
//				merged[i][j] = arr2[i][k];
//				j++;
//				k++;
//			}
//
//			// Null terminate the merged string
//			merged[i][j] = '\0';
//		}
//
//		// Output
//		cout << "\nMerged Names:\n";
//		for (int i = 0; i < r; i++) {
//			cout << merged[i] << endl;
//		}
//
//		// Clean up
//		for (int i = 0; i < r; i++) {
//			delete[] arr1[i];
//			delete[] arr2[i];
//			delete[] merged[i];
//		}
//		delete[] arr1;
//		delete[] arr2;
//		delete[] merged;
//
//		return 0;
//	}
//
//	
//	


	                                      // last task of this lab  



//
//#include<iostream>
//#include<fstream>
//	using namespace std;
//
//	int main() {
//		ifstream file("data.txt");
//		int r, c = 3;
//
//		file >> r;
//
//		int arr[10][3];  // Maximum 10 rows assumed
//
//		// Reading matrix
//		for (int i = 0; i < r; i++) {
//			for (int j = 0; j < c; j++) {
//				file >> arr[i][j];
//			}
//		}
//
//		// Converting 2D array to 1D for sorting
//		int total = r * c;
//		int temp[30];
//		int index = 0;
//
//		for (int i = 0; i < r; i++) {
//			for (int j = 0; j < c; j++) {
//				temp[index] = arr[i][j];
//				index++;
//			}
//		}
//
//		// Sorting the 1D array (ascending)
//		for (int i = 0; i < total - 1; i++) {
//			for (int j = i + 1; j < total; j++) {
//				if (temp[i] > temp[j]) {
//					int t = temp[i];
//					temp[i] = temp[j];
//					temp[j] = t;
//				}
//			}
//		}
//
//		// Putting sorted values back into 2D array
//		index = 0;
//		for (int i = 0; i < r; i++) {
//			for (int j = 0; j < c; j++) {
//				arr[i][j] = temp[index];
//				index++;
//			}
//		}
//
//		// Outputting sorted matrix
//		cout << "Updated Matrix A (sorted ascending):" << endl;
//		for (int i = 0; i < r; i++) {
//			for (int j = 0; j < c; j++) {
//				cout << arr[i][j] << " ";
//			}
//			cout << endl;
//		}
//
//		return 0;
//	}













	return 0;
}