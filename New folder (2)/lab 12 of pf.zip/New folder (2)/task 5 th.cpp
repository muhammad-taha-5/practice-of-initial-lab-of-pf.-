//#include<iostream> 
//#include<fstream>
//using namespace std;
//int main() {
//	ifstream read("r.txt");
//
//	int  r, c;
//	read >> r >> c;
//
//	int** sum = new  int* [r];
//	for (int i = 0; i < r; i++){
//		sum[i] = new  int[c];
//	}
//
//	if (read.is_open()) {
//
//		cout << endl;
//		for (int i = 0; i < r; i++) {
//			for (int j = 0; j < c; j++) {
//				read >> sum[i][j];
//
//			}
//			cout << endl;
//		}
//		cout << endl;
//		cout << endl; 
//		int arr[4];
//
//
//
//	  // jjust coloum wise sortting 
//	
//		for (int i = 0; i < r; i++) {
//			for (int j = 0; j < c; j++) {
//				cout << sum[i][j] << " ";
//
//			}
//			cout << endl;
//		}
//
//
//		for (int i = 0; i < r; i++) {
//			for (int j = 0; j < c; j++) {
//				
//
//				if (sum[i][j] > sum[i][j+1] ){
//					int temp = sum[i][j];
//					sum[i][j + 1] = sum[i][j];
//					sum[i][j] =  temp;  
//				}
//			}
//			cout << endl;
//		}
//
//		for (int i = 0; i < r; i++) {
//			for (int j = 0; j < c; j++) {
//				 cout <<  sum[i][j]<< " ";
//
//			}
//			cout << endl;
//		}
//
//	}
//	else {
//		cout << "  not open" << endl;
//	}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//	return 0;
//}
