#include<iostream> 
#include<fstream>
using namespace std;
int main() {
	ifstream read("r.txt");

	int  r, c;
	read >> r;
	c = 15;
	read.ignore();
	char ** arr = new  char * [r];
	for (int i = 0; i < r; i++) {
		arr[i] = new  char[c];
	}
	char arr2[15];

	if (read.is_open()){
		cout << endl;
		for (int i = 0; i < r; i++) {
			read.getline(arr[i], 50);
		}
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {

				if ( i == 2 ){

					arr2[j] = arr[2][j];

					arr[2][j] = arr[4][j];

					arr[4][j] = arr2[j];

				}
				cout << arr[i][j] << "";
			}
				cout << endl;
		}
		





	}
	else {
		cout << "  not open" << endl;
	}






















	return 0;
}