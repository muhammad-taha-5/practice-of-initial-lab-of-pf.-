#include<iostream> 
#include<fstream>
using namespace std; 
int main(){
	ifstream read("r.txt");

	int  r, c; 
	read >> r >> c;

	

	if (read.is_open() ){

		cout <<" open"<< endl;

	  int** arr = new  int * [r]; //  dynamic alocation of the  rows 
	   for (int i = 0; i < r; i++ ) {
		arr[i] = new  int [c];    //  dynamic alocation of the  cols
	   }

	 /* for (int i = 0; i < r; i++){
		for (int j = 0; j < c; j++){
			arr[i][j] = rand();
		}
      }*/
		 while (!read.eof()){
			for (int i = 0; i < r; i++) {
				for (int j = 0; j < c; j++) {
					read >> arr[i][j];
				}
			}
		 }



		 for (int i = 0; i < r; i++) {
			 for (int j = 0; j < c; j++) {
				 cout<< arr[i][j]<< " ";
			 }
			 cout << endl; 
		 }
		 //   REVERSED 

		 cout <<" REVERSED "<<  endl; cout << endl;
		 for (int i = r-1; i >=0; i--) {
			 for (int j = c-1 ; j >= 0; j--) {
				 cout << arr[i][j] << " ";
			 }
			 cout << endl;
		 }
	}
	else {
		cout << "  not open" << endl;
	}

	




















	return 0; 
}
