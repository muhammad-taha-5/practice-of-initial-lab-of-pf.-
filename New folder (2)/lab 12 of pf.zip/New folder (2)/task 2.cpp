#include<iostream> 
#include<fstream>
using namespace std;
int main() {
	ifstream read("r.txt");

	int  r, c;
	read >> r >> c;

	int** arr = new int* [r];
	for (int i = 0; i < r; i++) {
		arr[i] = new int[c];
	}
	if (read.is_open()) {
		cout << endl;
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++){
				read >> arr[i][j];
			}
			
		}
		int  r2, c2;
			read >> r2 >> c2;

			int** arr2 = new int* [r2];
			for (int i = 0; i < r2; i++) {
				arr2[i] = new int[c2];
			}

		for (int i = 0; i < r2; i++) {
			for (int j = 0; j < c2; j++) {
				read >> arr2[i][j];
			}
			
		}


		int** sum = new int* [r2];
		for (int i = 0; i < r2; i++) {
			sum[i] = new int[c2];
		}



		for (int i = 0; i < r2; i++) {
			for (int j = 0; j < c2; j++) {
				sum[i][j] = arr2[i][j] + arr[i][j];
			}
			
		}





		for (int i = 0; i < r2; i++) {
			for (int j = 0; j < c2; j++) {
				cout << sum[i][j] << " ";
			}
			cout << endl;
		}











	}
	else {
		cout << "  not open" << endl;
	}






















	return 0;
}
