#include< iostream>
using namespace std;
int  main() {
	// this way of the arr , 
	int arr[4][4] = {12,55,7,13,
					  56,4,89,15,
					  33,41,32,24,
					  13,66,14,23 };

	//  this is  the way to take the 2d arr  dynamically arr by user .

	//int row, colum;
	//	cout << "enter numebr of rows and columns ";
	//	cin >> row >> colum;
	//	int** p1 = new int* [row]; // array of row pointers
	//	for (int i = 0; i < row; i++) {
	//		p1[i] = new int[colum];  // allocate each row
	//	}

	

	// now the arr and then sort the arr 
	int arr2[10];
	for (int r = 0; r < 4; r++) {
		for (int c = 0; c < 4; c++) {
			arr2[c]=arr[r][c];

		}

		for (int k = 0; k < 4;k++ ) {
			for (int j = 0; j < 4;  j++) {
				if ( arr2[j] > arr2[j+1] ) {
					 
					int temp = arr[k][j];
					arr2[j] = arr2[j + 1];
					arr2[j + 1] = temp;

				}
			}
		}
		for (int k = 0; k < 4; k++) {
			arr[r][k] = arr2[k];

		}
	}


	for (int r = 0; r < 4; r++) {
		for (int c = 0; c < 4; c++) {
			 
			 cout << arr[r][c]<< " ";
		}
	}
	return 0;
}