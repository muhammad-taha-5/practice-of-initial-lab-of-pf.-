#include< iostream>
using namespace std;
int  main() {
	// this way of the arr , 
	int arr[2][3] = { 1,2,3
                     ,4,5,6 };

	//  this is  the way to take the 2d arr  dynamically arr by user .

	//int row, colum;
	//	cout << "enter numebr of rows and columns ";
	//	cin >> row >> colum;
	//	int** p1 = new int* [row]; // array of row pointers
	//	for (int i = 0; i < row; i++) {
	//		p1[i] = new int[colum];  // allocate each row
	//	}

	// int sum[3];


	int sum[3]={0};

		for (int c = 0; c <3; c++){
			
			for (int r = 0; r< 2; r++) {

			  	  
					  cout<< " " << arr[r][c];
				      	 sum[c] += arr[r][c];


			}
			cout << endl;

		}


		for (int r = 0; r < 3; r++) {

				 cout << sum[r] << " ";

	    }
		

			 
		

	cout << endl;
	cout << endl;
	
	      int sum2[2] = { 0 };

		for (int r = 0; r < 2; r++){

	      for (int c = 0; c < 3; c++){


			cout << " " << arr[r][c];
			sum2[r] += arr[r][c];


		  }
		  cout << endl; 

	    }


	for (int r = 0; r < 2; r++){

		cout << sum2[r] << " ";

	}



	return 0;
}