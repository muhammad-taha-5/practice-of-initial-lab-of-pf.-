//#include< iostream>
//using namespace std;
//int main() {
//	int row, colum;
//	cout << "enter numebr of rows and columns ";
//	cin >> row >> colum;
//	int** p1 = new int* [row]; // array of row pointers
//	for (int i = 0; i < row; i++) {
//		p1[i] = new int[colum];  // allocate each row
//	}
//
//	cout << "enter values ";
//	for (int i = 0; i < row; i++) {
//		for (int j = 0; j < colum; j++)
//		{
//			cin >> p1[i][j];
//
//		}
//	}
//	cout << "inputted values ";
//	for (int i = 0; i < row; i++) {
//		for (int j = 0; j < colum; j++)
//		{
//			cout << p1[i][j] << " ";
//
//		}
//		cout << endl;
//	}
//
//	int** p2 = new int* [row]; // array of row pointers
//	for (int i = 0; i < row; i++) {
//		p2[i] = new int[colum];  // allocate each row
//	}
//
//	int* simpleArr = new int[colum];
//	for (int i = 0; i < row; i++) {
//		for (int j = 0; j < colum; j++)
//		{
//
//			simpleArr[j] = p1[i][j];
//
//
//		}
//		for (int k = 0; k < colum - 1; k++){
//			for (int j = 0; j < colum - k - 1; j++) {
//				if (simpleArr[j] > simpleArr[j + 1]) {
//					// swap arr[j] and arr[j + 1]
//					int temp = simpleArr[j];
//					simpleArr[j] = simpleArr[j + 1]; 
//					simpleArr[j + 1] = temp;
//				}
//			}
//		}
//		for (int j = 0; j < colum; j++)
//		{
//
//			p2[i][j]= simpleArr[j] ;
//
//
//		}
//
//	}
//
//	cout << "final matrix ";
//	for (int i = 0; i < row; i++) {
//		for (int j = 0; j < colum; j++)
//		{
//			cout << p2[i][j] << " ";
//
//		}
//		cout << endl;
//	}
//
//	return 0;
//}