#include< iostream>
using namespace std;
int  main() {
	// this way of the arr , 

	 const int col =3, row = 3;
	
	int arr[row][col] ={ 1,2,3 ,
					     4,5,6
					    ,7,8,9
	                                 };


	//  this is  the way to take the 2d arr  dynamically arr by user .

	//int row, colum;
	//	cout << "enter numebr of rows and columns ";
	//	cin >> row >> colum;
	//	int** p1 = new int* [row]; // array of row pointers
	//	for (int i = 0; i < row; i++) {
	//		p1[i] = new int[colum];  // allocate each row



	for (int i = 0; i < row; i++) {

		for (int j = i + 1; j < col; j++) {
			int temp = arr[i][j] ;
			arr[i][j] = arr[j][i];
			arr[j][i] = temp;
		}
	}

	// now for the revrse the each row
	cout << endl;
	int  arr2[3] = { 0 };
	for (int i = 0; i < row; i++) {
		for (int c = 0; c < col; c++ ) {
			arr2[c] = arr[i][c];

		}
		int index = 2;
		for (int j =  0; j < col ; j++){
			arr[i][j] = arr2[index];

			index--;
		}
	}

	// now for vewing the arr 
	for (int r = 0; r < row; r++){
		for (int c = 0; c < col; c++){

			 cout<<" "<< arr[r][c];

		}
			 cout << endl;
		
	}
 

	return 0;
}